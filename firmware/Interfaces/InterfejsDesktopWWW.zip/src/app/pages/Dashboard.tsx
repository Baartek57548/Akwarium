import { useState, useEffect } from "react";
import {
  Thermometer,
  Lightbulb,
  Filter,
  Flame,
  Wind,
  Fish,
  Wifi,
  Battery,
  BatteryFull,
  BatteryMedium,
  BatteryLow,
  Clock,
  Activity,
  Zap,
  TrendingUp,
  TrendingDown,
  Minus,
  ChevronRight,
  RefreshCw,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
} from "recharts";
import { useDevice } from "../deviceContext";
import { tempHistory } from "../tempHistory";
import { Link } from "react-router";

function StatCard({
  label,
  value,
  unit,
  sublabel,
  icon: Icon,
  color,
  trend,
}: {
  label: string;
  value: string | number;
  unit?: string;
  sublabel?: string;
  icon: React.ElementType;
  color: string;
  trend?: "up" | "down" | "stable";
}) {
  const TrendIcon = trend === "up" ? TrendingUp : trend === "down" ? TrendingDown : Minus;
  return (
    <div
      className="rounded-2xl p-5 flex flex-col gap-3"
      style={{
        background: `linear-gradient(135deg, ${color}12 0%, rgba(7,9,26,0.8) 100%)`,
        border: `1px solid ${color}28`,
      }}
    >
      <div className="flex items-center justify-between">
        <div
          className="rounded-xl p-2"
          style={{ background: `${color}18`, border: `1px solid ${color}25` }}
        >
          <Icon size={17} style={{ color }} />
        </div>
        {trend && (
          <TrendIcon
            size={14}
            style={{
              color:
                trend === "up" ? "#f87171" : trend === "down" ? "#60a5fa" : "#94a3b8",
            }}
          />
        )}
      </div>
      <div>
        <div className="flex items-end gap-1.5">
          <span
            style={{ fontSize: 28, color: "#f1f5f9", letterSpacing: "-0.03em", lineHeight: 1 }}
          >
            {value}
          </span>
          {unit && <span style={{ fontSize: 14, color: "#64748b", paddingBottom: 2 }}>{unit}</span>}
        </div>
        <p style={{ fontSize: 12, color: "#64748b", marginTop: 3 }}>{label}</p>
        {sublabel && <p style={{ fontSize: 11, color, marginTop: 1 }}>{sublabel}</p>}
      </div>
    </div>
  );
}

function RelayCard({
  label,
  sublabel,
  icon: Icon,
  active,
  color,
  onToggle,
}: {
  label: string;
  sublabel?: string;
  icon: React.ElementType;
  active: boolean;
  color: string;
  onToggle: () => void;
}) {
  return (
    <button
      onClick={onToggle}
      className="rounded-2xl p-4 flex flex-col gap-3 text-left transition-all hover:scale-[1.02] active:scale-[0.98]"
      style={{
        background: active
          ? `linear-gradient(135deg, ${color}18 0%, ${color}08 100%)`
          : "rgba(255,255,255,0.03)",
        border: `1px solid ${active ? color + "40" : "rgba(255,255,255,0.07)"}`,
        boxShadow: active ? `0 4px 20px ${color}18` : "none",
        cursor: "pointer",
      }}
    >
      <div className="flex items-center justify-between">
        <div
          className="rounded-xl p-2"
          style={{ background: active ? `${color}20` : "rgba(255,255,255,0.06)" }}
        >
          <Icon size={17} style={{ color: active ? color : "#4b5563" }} />
        </div>
        <div
          className="rounded-full"
          style={{
            width: 8,
            height: 8,
            background: active ? color : "#374151",
            boxShadow: active ? `0 0 8px ${color}` : "none",
          }}
        />
      </div>
      <div>
        <p style={{ fontSize: 13, color: active ? "#e2e8f0" : "#9ca3af" }}>{label}</p>
        {sublabel && (
          <p style={{ fontSize: 11, color: active ? color : "#4b5563", marginTop: 2 }}>{sublabel}</p>
        )}
      </div>
    </button>
  );
}

const ChartTooltip = ({ active, payload, label }: any) => {
  if (active && payload?.length) {
    return (
      <div
        className="rounded-xl px-3 py-2"
        style={{
          background: "#0f1829",
          border: "1px solid rgba(6,182,212,0.3)",
          color: "#e2e8f0",
          fontSize: 12,
        }}
      >
        <p style={{ color: "#64748b", marginBottom: 2 }}>{label}</p>
        <p style={{ color: "#22d3ee" }}>{payload[0].value.toFixed(2)} °C</p>
      </div>
    );
  }
  return null;
};

export function Dashboard() {
  const { state, toggleLight, toggleFilter, toggleHeater, setAeration, feedNow } = useDevice();
  const [time, setTime] = useState(new Date());
  const [feedFeedback, setFeedFeedback] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const handleFeed = () => {
    feedNow();
    setFeedFeedback(true);
    setTimeout(() => setFeedFeedback(false), 3000);
  };

  const handleRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1000);
  };

  const chartData = tempHistory;
  const minTemp = Math.min(...chartData.map((d) => d.temp)) - 0.3;
  const maxTemp = Math.max(...chartData.map((d) => d.temp)) + 0.3;

  const batColor =
    state.batteryPercent > 70 ? "#4ade80" : state.batteryPercent > 35 ? "#fbbf24" : "#f87171";
  const BatIcon =
    state.batteryPercent > 70 ? BatteryFull : state.batteryPercent > 35 ? BatteryMedium : BatteryLow;
  const tempColor =
    state.currentTemp > 27 ? "#f87171" : state.currentTemp < 23 ? "#60a5fa" : "#22d3ee";

  return (
    <div className="flex flex-col" style={{ minHeight: "100%" }}>
      {/* Page header */}
      <div
        className="flex items-center justify-between px-8 py-5"
        style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}
      >
        <div>
          <h1 style={{ fontSize: 20, color: "#f1f5f9" }}>Panel główny</h1>
          <p style={{ fontSize: 12, color: "#64748b", marginTop: 1 }}>
            {time.toLocaleDateString("pl-PL", {
              weekday: "long",
              year: "numeric",
              month: "long",
              day: "numeric",
            })}{" "}
            · {time.toLocaleTimeString("pl-PL")}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div
            className="flex items-center gap-2 rounded-xl px-3 py-2"
            style={{
              background: "rgba(255,255,255,0.04)",
              border: "1px solid rgba(255,255,255,0.08)",
            }}
          >
            <div
              style={{
                width: 7,
                height: 7,
                borderRadius: "50%",
                background: state.wifi.connected ? "#4ade80" : "#f87171",
                boxShadow: state.wifi.connected ? "0 0 6px #4ade80" : "none",
              }}
            />
            <span style={{ fontSize: 12, color: "#94a3b8" }}>
              {state.wifi.connected ? state.wifi.ip : "Offline"}
            </span>
          </div>
          <button
            onClick={handleRefresh}
            className="flex items-center gap-2 rounded-xl px-3 py-2 transition-all hover:bg-white/5"
            style={{ border: "1px solid rgba(255,255,255,0.08)", color: "#94a3b8" }}
          >
            <RefreshCw size={14} className={refreshing ? "animate-spin" : ""} />
            <span style={{ fontSize: 12 }}>Odśwież</span>
          </button>
        </div>
      </div>

      <div className="flex flex-col gap-6 p-8">
        {/* Top stat cards */}
        <div className="grid grid-cols-4 gap-4">
          <StatCard
            label="Temperatura wody"
            value={state.currentTemp.toFixed(1)}
            unit="°C"
            sublabel={`cel: ${state.targetTemp}°C ±${state.hysteresis}°C`}
            icon={Thermometer}
            color={tempColor}
            trend="stable"
          />
          <StatCard
            label="Bateria RTC"
            value={state.batteryPercent}
            unit="%"
            sublabel={`${state.batteryVoltage.toFixed(2)} V`}
            icon={BatIcon}
            color={batColor}
            trend={state.batteryPercent < 35 ? "down" : "stable"}
          />
          <StatCard
            label="Sygnał WiFi"
            value={state.wifi.rssi}
            unit="dBm"
            sublabel={state.wifi.connected ? state.wifi.ssid : "Offline"}
            icon={Wifi}
            color={state.wifi.rssi > -60 ? "#4ade80" : state.wifi.rssi > -75 ? "#fbbf24" : "#f87171"}
            trend="stable"
          />
          <StatCard
            label="Czas pracy"
            value={state.uptime}
            icon={Zap}
            color="#a78bfa"
            sublabel="ESP32-S3 · FreeRTOS"
          />
        </div>

        {/* Middle row */}
        <div className="grid gap-4" style={{ gridTemplateColumns: "1fr 1fr 320px" }}>
          {/* Relays */}
          <div
            className="rounded-2xl p-5"
            style={{
              background: "rgba(255,255,255,0.025)",
              border: "1px solid rgba(255,255,255,0.07)",
            }}
          >
            <div className="flex items-center justify-between mb-4">
              <h2 style={{ fontSize: 14, color: "#94a3b8" }}>Przekaźniki</h2>
              <span style={{ fontSize: 11, color: "#475569" }}>
                {[state.lightOn, state.filterOn, state.heaterOn, state.aerationAngle > 0].filter(Boolean).length} / 4 aktywnych
              </span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <RelayCard
                label="Światło"
                sublabel={state.lightOn ? "GPIO17 · AKTYWNY" : "GPIO17 · wyłączone"}
                icon={Lightbulb}
                active={state.lightOn}
                color="#fbbf24"
                onToggle={toggleLight}
              />
              <RelayCard
                label="Filtr"
                sublabel={state.filterOn ? "GPIO4 · AKTYWNY" : "GPIO4 · wyłączony"}
                icon={Filter}
                active={state.filterOn}
                color="#60a5fa"
                onToggle={toggleFilter}
              />
              <RelayCard
                label="Grzałka"
                sublabel={state.heaterOn ? "GPIO3 · AKTYWNA" : "GPIO3 · wyłączona"}
                icon={Flame}
                active={state.heaterOn}
                color="#fb923c"
                onToggle={toggleHeater}
              />
              <RelayCard
                label="Napowietrzanie"
                sublabel={
                  state.aerationAngle > 0
                    ? `GPIO6 · serwo ${state.aerationAngle}°`
                    : "GPIO6 · wyłączone"
                }
                icon={Wind}
                active={state.aerationAngle > 0}
                color="#34d399"
                onToggle={() => setAeration(state.aerationAngle > 0 ? 0 : 45)}
              />
            </div>
          </div>

          {/* Schedule overview */}
          <div
            className="rounded-2xl p-5"
            style={{
              background: "rgba(255,255,255,0.025)",
              border: "1px solid rgba(255,255,255,0.07)",
            }}
          >
            <div className="flex items-center justify-between mb-4">
              <h2 style={{ fontSize: 14, color: "#94a3b8" }}>Harmonogram dziś</h2>
              <Link to="/schedule">
                <span
                  className="flex items-center gap-1 hover:text-cyan-300 transition-colors"
                  style={{ fontSize: 12, color: "#22d3ee" }}
                >
                  Edytuj <ChevronRight size={12} />
                </span>
              </Link>
            </div>
            <div className="flex flex-col gap-2">
              {[
                {
                  label: "Światło",
                  icon: Lightbulb,
                  color: "#fbbf24",
                  value: state.schedule.light.enabled
                    ? `${state.schedule.light.start} – ${state.schedule.light.end}`
                    : "Wyłączone",
                  active: state.schedule.light.enabled,
                },
                {
                  label: "Filtr",
                  icon: Filter,
                  color: "#60a5fa",
                  value: state.schedule.filter.enabled
                    ? `${state.schedule.filter.start} – ${state.schedule.filter.end}`
                    : "Wyłączony",
                  active: state.schedule.filter.enabled,
                },
                {
                  label: "Napowietrzanie",
                  icon: Wind,
                  color: "#34d399",
                  value: state.schedule.aeration.enabled
                    ? `${state.schedule.aeration.start} – ${state.schedule.aeration.end}`
                    : "Wyłączone",
                  active: state.schedule.aeration.enabled,
                },
                {
                  label: "Karmienie",
                  icon: Fish,
                  color: "#f472b6",
                  value:
                    state.schedule.feeding.mode === 0
                      ? "Wyłączone"
                      : `Codziennie ${state.schedule.feeding.time}`,
                  active: state.schedule.feeding.mode !== 0,
                },
              ].map(({ label, icon: Icon, color, value, active }) => (
                <div
                  key={label}
                  className="flex items-center gap-3 rounded-xl px-3 py-2.5"
                  style={{
                    background: active ? `${color}0a` : "rgba(255,255,255,0.02)",
                    border: `1px solid ${active ? color + "20" : "rgba(255,255,255,0.05)"}`,
                  }}
                >
                  <div
                    className="rounded-lg p-1.5"
                    style={{ background: `${color}15`, flexShrink: 0 }}
                  >
                    <Icon size={13} style={{ color: active ? color : "#4b5563" }} />
                  </div>
                  <span style={{ fontSize: 13, color: "#cbd5e1", flex: 1 }}>{label}</span>
                  <span style={{ fontSize: 12, color: active ? "#94a3b8" : "#374151" }}>{value}</span>
                </div>
              ))}
            </div>

            <div
              className="mt-3 rounded-xl px-3 py-2.5 flex items-center gap-2"
              style={{
                background: "rgba(34,211,238,0.06)",
                border: "1px solid rgba(34,211,238,0.12)",
              }}
            >
              <Clock size={12} style={{ color: "#22d3ee" }} />
              <span style={{ fontSize: 12, color: "#64748b" }}>
                Ostatnie karmienie: <span style={{ color: "#94a3b8" }}>{state.lastFeedTime}</span>
              </span>
            </div>
          </div>

          {/* Feed panel */}
          <div
            className="rounded-2xl p-5 flex flex-col"
            style={{
              background: "rgba(255,255,255,0.025)",
              border: "1px solid rgba(255,255,255,0.07)",
            }}
          >
            <h2 style={{ fontSize: 14, color: "#94a3b8", marginBottom: 16 }}>Karmnik</h2>
            <div className="flex flex-col items-center gap-4 flex-1 justify-center">
              <button
                onClick={handleFeed}
                className="relative flex flex-col items-center justify-center rounded-full transition-all hover:scale-105 active:scale-95"
                style={{
                  width: 120,
                  height: 120,
                  background: feedFeedback
                    ? "linear-gradient(135deg, rgba(52,211,153,0.2), rgba(52,211,153,0.05))"
                    : "linear-gradient(135deg, rgba(244,114,182,0.2), rgba(244,114,182,0.05))",
                  border: `2px solid ${feedFeedback ? "#34d399" : "#f472b6"}`,
                  boxShadow: feedFeedback
                    ? "0 0 30px rgba(52,211,153,0.3)"
                    : "0 0 24px rgba(244,114,182,0.2)",
                  cursor: "pointer",
                }}
              >
                <Fish size={34} style={{ color: feedFeedback ? "#34d399" : "#f472b6" }} />
                <span
                  style={{
                    fontSize: 11,
                    color: feedFeedback ? "#34d399" : "#f472b6",
                    marginTop: 8,
                  }}
                >
                  {feedFeedback ? "Karmię..." : "Karm teraz"}
                </span>
              </button>
              <div className="text-center">
                <p style={{ fontSize: 11, color: "#475569" }}>Tryb</p>
                <p style={{ fontSize: 13, color: "#94a3b8" }}>
                  {state.schedule.feeding.mode === 0 ? "Wyłączony" : `Codziennie ${state.schedule.feeding.time}`}
                </p>
              </div>
              <Link
                to="/feeder"
                className="flex items-center gap-1.5 rounded-xl px-4 py-2 transition-colors hover:bg-white/5"
                style={{
                  fontSize: 12,
                  color: "#64748b",
                  border: "1px solid rgba(255,255,255,0.07)",
                }}
              >
                Zarządzaj <ChevronRight size={12} />
              </Link>
            </div>
          </div>
        </div>

        {/* Temperature chart */}
        <div
          className="rounded-2xl p-6"
          style={{
            background: "rgba(255,255,255,0.025)",
            border: "1px solid rgba(255,255,255,0.07)",
          }}
        >
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-3">
              <Activity size={16} style={{ color: "#22d3ee" }} />
              <div>
                <h2 style={{ fontSize: 14, color: "#94a3b8" }}>Historia temperatury</h2>
                <p style={{ fontSize: 11, color: "#475569" }}>Ostatnie 24 godziny · co 30 minut</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              {[
                {
                  label: "Minimum",
                  val: `${Math.min(...chartData.map((d) => d.temp)).toFixed(1)}°C`,
                  color: "#60a5fa",
                },
                {
                  label: "Maksimum",
                  val: `${Math.max(...chartData.map((d) => d.temp)).toFixed(1)}°C`,
                  color: "#f87171",
                },
                { label: "Aktualna", val: `${state.currentTemp.toFixed(1)}°C`, color: "#22d3ee" },
                { label: "Docelowa", val: `${state.targetTemp.toFixed(1)}°C`, color: "#a78bfa" },
              ].map(({ label, val, color }) => (
                <div key={label} className="text-right">
                  <p style={{ fontSize: 10, color: "#475569" }}>{label}</p>
                  <p style={{ fontSize: 14, color }}>{val}</p>
                </div>
              ))}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={chartData} margin={{ top: 5, right: 5, bottom: 0, left: -10 }}>
              <defs key="defs">
                <linearGradient id="tempGradDesktop" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#22d3ee" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#22d3ee" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis
                key="xaxis"
                dataKey="time"
                tick={{ fill: "#475569", fontSize: 10 }}
                tickLine={false}
                axisLine={false}
                interval={5}
              />
              <YAxis
                key="yaxis"
                domain={[minTemp, maxTemp]}
                tick={{ fill: "#475569", fontSize: 10 }}
                tickLine={false}
                axisLine={false}
                tickFormatter={(v) => `${v.toFixed(1)}°`}
              />
              <Tooltip key="tooltip" content={<ChartTooltip />} />
              <ReferenceLine
                key="ref-target"
                y={state.targetTemp}
                stroke="#a78bfa"
                strokeWidth={1}
                strokeDasharray="4 4"
                opacity={0.5}
              />
              <ReferenceLine
                key="ref-emergency"
                y={28}
                stroke="#f87171"
                strokeWidth={1}
                strokeDasharray="4 2"
                opacity={0.4}
              />
              <Area
                key="area-temp"
                type="monotone"
                dataKey="temp"
                stroke="#22d3ee"
                strokeWidth={2}
                fill="url(#tempGradDesktop)"
                dot={false}
                activeDot={{ r: 4, fill: "#22d3ee", stroke: "#0f172a", strokeWidth: 2 }}
              />
            </AreaChart>
          </ResponsiveContainer>
          <div className="flex items-center gap-4 mt-2" style={{ paddingLeft: 36 }}>
            <div className="flex items-center gap-1.5">
              <div style={{ width: 20, height: 1, background: "#a78bfa", opacity: 0.5 }} />
              <span style={{ fontSize: 10, color: "#64748b" }}>Temperatura docelowa</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div style={{ width: 20, height: 1, background: "#f87171", opacity: 0.4 }} />
              <span style={{ fontSize: 10, color: "#64748b" }}>Limit awaryjny (28°C)</span>
            </div>
          </div>
        </div>

        {/* Bottom row: logs preview + system */}
        <div className="grid grid-cols-2 gap-4">
          {/* Recent logs */}
          <div
            className="rounded-2xl p-5"
            style={{
              background: "rgba(255,255,255,0.025)",
              border: "1px solid rgba(255,255,255,0.07)",
            }}
          >
            <div className="flex items-center justify-between mb-4">
              <h2 style={{ fontSize: 14, color: "#94a3b8" }}>Ostatnie logi</h2>
              <Link to="/logs">
                <span
                  className="flex items-center gap-1 hover:text-cyan-300 transition-colors"
                  style={{ fontSize: 12, color: "#22d3ee" }}
                >
                  Wszystkie <ChevronRight size={12} />
                </span>
              </Link>
            </div>
            <div className="flex flex-col gap-1">
              {state.logs.slice(0, 6).map((log) => {
                const levelColor =
                  log.level === "INFO" ? "#22d3ee" : log.level === "WARN" ? "#fbbf24" : "#f87171";
                return (
                  <div
                    key={log.id}
                    className="flex items-start gap-2.5 rounded-lg px-3 py-2"
                    style={{ background: "rgba(255,255,255,0.02)" }}
                  >
                    <span
                      className="rounded px-1.5 py-0.5 shrink-0 mt-0.5"
                      style={{
                        fontSize: 9,
                        color: levelColor,
                        background: `${levelColor}15`,
                        border: `1px solid ${levelColor}25`,
                        letterSpacing: "0.04em",
                      }}
                    >
                      {log.level}
                    </span>
                    <span style={{ fontSize: 11, color: "#64748b", flexShrink: 0 }}>
                      {log.timestamp}
                    </span>
                    <span style={{ fontSize: 12, color: "#cbd5e1" }}>{log.message}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* System status */}
          <div
            className="rounded-2xl p-5"
            style={{
              background: "rgba(255,255,255,0.025)",
              border: "1px solid rgba(255,255,255,0.07)",
            }}
          >
            <h2 style={{ fontSize: 14, color: "#94a3b8", marginBottom: 16 }}>Stan systemu</h2>
            <div className="flex flex-col gap-2">
              {[
                {
                  label: "Platforma",
                  value: "ESP32-S3-DevKitC-1",
                  color: "#94a3b8",
                },
                {
                  label: "Framework",
                  value: "Arduino / FreeRTOS dual-core",
                  color: "#94a3b8",
                },
                {
                  label: "Temperatura grzałki",
                  value: state.heaterOn ? "WŁĄCZONA" : "wyłączona",
                  color: state.heaterOn ? "#fb923c" : "#475569",
                },
                {
                  label: "Limit awaryjny",
                  value: "28.0°C – fail-safe ON",
                  color: "#f87171",
                },
                {
                  label: "Deep Sleep",
                  value: state.alwaysScreenOn ? "Wyłączony (always-on)" : "po 5 min bezczynności",
                  color: "#94a3b8",
                },
                {
                  label: "AP Status",
                  value: state.wifi.apActive
                    ? `${state.wifi.apSsid} · ${state.wifi.apIp}`
                    : "wyłączony",
                  color: state.wifi.apActive ? "#38bdf8" : "#475569",
                },
                {
                  label: "Logi krytyczne",
                  value: `${state.criticalLogs.length} wpisów (Flash)`,
                  color: state.criticalLogs.length > 0 ? "#fbbf24" : "#475569",
                },
                {
                  label: "GPIO Serwa",
                  value: `GPIO6 · ${state.aerationAngle}° ${state.manualServoAngle !== null ? "(override)" : "(harmonogram)"}`,
                  color: "#94a3b8",
                },
              ].map(({ label, value, color }) => (
                <div
                  key={label}
                  className="flex items-center rounded-lg px-3 py-2"
                  style={{ background: "rgba(255,255,255,0.02)" }}
                >
                  <span style={{ fontSize: 12, color: "#64748b", flex: 1 }}>{label}</span>
                  <span style={{ fontSize: 12, color }}>{value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}