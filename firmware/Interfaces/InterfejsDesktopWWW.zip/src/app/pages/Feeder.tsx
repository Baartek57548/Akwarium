import { useState } from "react";
import {
  Fish,
  Clock,
  CheckCircle2,
  AlertCircle,
  Activity,
  Cpu,
  Timer,
  BarChart3,
} from "lucide-react";
import { useDevice } from "../deviceContext";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const feedingHistory = [
  { day: "Pon", count: 1 },
  { day: "Wt", count: 1 },
  { day: "Śr", count: 1 },
  { day: "Czw", count: 2 },
  { day: "Pt", count: 1 },
  { day: "Sob", count: 1 },
  { day: "Nd", count: 1 },
];

export function Feeder() {
  const { state, feedNow } = useDevice();
  const [feeding, setFeeding] = useState<"idle" | "running" | "done">("idle");
  const [progress, setProgress] = useState(0);

  const handleFeed = () => {
    if (feeding !== "idle") return;
    setFeeding("running");
    setProgress(0);
    feedNow();
    let p = 0;
    const interval = setInterval(() => {
      p += 7;
      setProgress(Math.min(p, 100));
      if (p >= 100) {
        clearInterval(interval);
        setFeeding("done");
        setTimeout(() => { setFeeding("idle"); setProgress(0); }, 3000);
      }
    }, 100);
  };

  return (
    <div style={{ minHeight: "100%", color: "#e2e8f0" }}>
      {/* Header */}
      <div
        className="flex items-center justify-between px-8 py-5"
        style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}
      >
        <div>
          <h1 style={{ fontSize: 20, color: "#f1f5f9" }}>Karmnik</h1>
          <p style={{ fontSize: 12, color: "#64748b", marginTop: 1 }}>
            Sterowanie ręczne i konfiguracja harmonogramu
          </p>
        </div>
      </div>

      <div className="p-8 grid gap-6" style={{ gridTemplateColumns: "320px 1fr" }}>
        {/* Left: Feed control */}
        <div className="flex flex-col gap-4">
          {/* Manual feed */}
          <div
            className="rounded-2xl p-6 flex flex-col items-center gap-5"
            style={{
              background: "linear-gradient(135deg, rgba(244,114,182,0.1) 0%, rgba(7,9,26,0.9) 100%)",
              border: "1px solid rgba(244,114,182,0.2)",
            }}
          >
            <p style={{ fontSize: 13, color: "#94a3b8" }}>Karmienie ręczne</p>

            {/* Ring + button */}
            <div className="relative" style={{ width: 160, height: 160 }}>
              <svg
                className="absolute inset-0"
                style={{ width: 160, height: 160, transform: "rotate(-90deg)" }}
                viewBox="0 0 160 160"
              >
                <circle cx="80" cy="80" r="72" fill="none" stroke="rgba(244,114,182,0.1)" strokeWidth="6" />
                {feeding === "running" && (
                  <circle
                    cx="80"
                    cy="80"
                    r="72"
                    fill="none"
                    stroke="#f472b6"
                    strokeWidth="6"
                    strokeLinecap="round"
                    strokeDasharray={`${2 * Math.PI * 72}`}
                    strokeDashoffset={`${2 * Math.PI * 72 * (1 - progress / 100)}`}
                    style={{ transition: "stroke-dashoffset 0.1s linear" }}
                  />
                )}
                {feeding === "done" && (
                  <circle cx="80" cy="80" r="72" fill="none" stroke="#4ade80" strokeWidth="6" />
                )}
              </svg>

              <button
                onClick={handleFeed}
                disabled={feeding !== "idle"}
                className="absolute inset-3 flex flex-col items-center justify-center rounded-full transition-all hover:scale-105 active:scale-95"
                style={{
                  background:
                    feeding === "done"
                      ? "rgba(74,222,128,0.12)"
                      : "rgba(244,114,182,0.1)",
                  border: `2px solid ${feeding === "done" ? "#4ade80" : feeding === "running" ? "#f472b6" : "rgba(244,114,182,0.4)"}`,
                  boxShadow:
                    feeding === "done"
                      ? "0 0 30px rgba(74,222,128,0.25)"
                      : "0 0 20px rgba(244,114,182,0.15)",
                  cursor: feeding !== "idle" ? "default" : "pointer",
                }}
              >
                {feeding === "done" ? (
                  <>
                    <CheckCircle2 size={32} style={{ color: "#4ade80" }} />
                    <span style={{ fontSize: 12, color: "#4ade80", marginTop: 8 }}>Gotowe!</span>
                  </>
                ) : feeding === "running" ? (
                  <>
                    <Activity size={32} style={{ color: "#f472b6" }} />
                    <span style={{ fontSize: 12, color: "#f472b6", marginTop: 8 }}>
                      {Math.round(progress)}%
                    </span>
                  </>
                ) : (
                  <>
                    <Fish size={32} style={{ color: "#f472b6" }} />
                    <span style={{ fontSize: 12, color: "#f472b6", marginTop: 8 }}>Karm teraz</span>
                  </>
                )}
              </button>
            </div>

            <p style={{ fontSize: 12, color: "#64748b", textAlign: "center", maxWidth: 220 }}>
              {feeding === "running"
                ? "Karmnik w trakcie pracy… timeout: 15s"
                : feeding === "done"
                ? "Karmienie zakończone pomyślnie"
                : "Kliknij, aby uruchomić karmnik jednorazowo"}
            </p>
          </div>

          {/* Last feed / schedule */}
          <div
            className="rounded-2xl p-4 flex flex-col gap-3"
            style={{
              background: "rgba(255,255,255,0.025)",
              border: "1px solid rgba(255,255,255,0.07)",
            }}
          >
            <div className="flex items-center gap-2.5">
              <div className="rounded-xl p-1.5" style={{ background: "rgba(244,114,182,0.12)" }}>
                <Clock size={15} style={{ color: "#f472b6" }} />
              </div>
              <div>
                <p style={{ fontSize: 11, color: "#64748b" }}>Ostatnie karmienie</p>
                <p style={{ fontSize: 14, color: "#e2e8f0" }}>{state.lastFeedTime}</p>
              </div>
            </div>
            <div className="flex items-center gap-2.5">
              <div className="rounded-xl p-1.5" style={{ background: "rgba(244,114,182,0.12)" }}>
                <Timer size={15} style={{ color: "#f472b6" }} />
              </div>
              <div>
                <p style={{ fontSize: 11, color: "#64748b" }}>Harmonogram</p>
                <p style={{ fontSize: 14, color: "#e2e8f0" }}>
                  {state.schedule.feeding.mode === 0
                    ? "Wyłączony"
                    : `Codziennie ${state.schedule.feeding.time}`}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Info + chart */}
        <div className="flex flex-col gap-4">
          {/* Stats */}
          <div className="grid grid-cols-3 gap-4">
            {[
              { label: "Karmieniami dziś", value: "1", color: "#f472b6" },
              { label: "Timeout bezp.", value: "15s", color: "#fbbf24" },
              { label: "Tryb", value: state.schedule.feeding.mode === 0 ? "Wył." : "Dzienny", color: "#34d399" },
            ].map(({ label, value, color }) => (
              <div
                key={label}
                className="rounded-2xl p-4"
                style={{
                  background: `${color}0a`,
                  border: `1px solid ${color}20`,
                }}
              >
                <p style={{ fontSize: 24, color, letterSpacing: "-0.02em" }}>{value}</p>
                <p style={{ fontSize: 11, color: "#64748b", marginTop: 2 }}>{label}</p>
              </div>
            ))}
          </div>

          {/* Chart */}
          <div
            className="rounded-2xl p-5"
            style={{
              background: "rgba(255,255,255,0.025)",
              border: "1px solid rgba(255,255,255,0.07)",
            }}
          >
            <div className="flex items-center gap-2 mb-4">
              <BarChart3 size={15} style={{ color: "#f472b6" }} />
              <h2 style={{ fontSize: 14, color: "#94a3b8" }}>Aktywność karmnika — ostatni tydzień</h2>
            </div>
            <ResponsiveContainer width="100%" height={120}>
              <BarChart data={feedingHistory} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                <XAxis dataKey="day" tick={{ fill: "#475569", fontSize: 11 }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fill: "#475569", fontSize: 11 }} tickLine={false} axisLine={false} allowDecimals={false} />
                <Tooltip
                  contentStyle={{
                    background: "#0f1829",
                    border: "1px solid rgba(244,114,182,0.3)",
                    borderRadius: 10,
                    color: "#e2e8f0",
                    fontSize: 12,
                  }}
                  cursor={{ fill: "rgba(255,255,255,0.04)" }}
                />
                <Bar dataKey="count" fill="#f472b6" radius={[4, 4, 0, 0]} opacity={0.8} name="Karmień" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* GPIO / safety info */}
          <div
            className="rounded-2xl p-5"
            style={{
              background: "rgba(255,255,255,0.025)",
              border: "1px solid rgba(255,255,255,0.07)",
            }}
          >
            <div className="flex items-center gap-2 mb-4">
              <Cpu size={15} style={{ color: "#94a3b8" }} />
              <h2 style={{ fontSize: 14, color: "#94a3b8" }}>Parametry sprzętowe</h2>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {[
                { label: "Silnik karmnika", value: "GPIO5 (FEEDER_PIN)", color: "#f472b6" },
                { label: "Czujnik ukończenia", value: "GPIO12 (FEEDER_SENSOR_PIN)", color: "#f472b6" },
                { label: "Timeout bezpieczeństwa", value: "15 sekund", color: "#fbbf24" },
                { label: "Logika czujnika", value: "Detekcja cyklu + zacięcia", color: "#94a3b8" },
                { label: "Karmienie API", value: "POST /api/action · feed_now", color: "#22d3ee" },
                { label: "Ostatnie zdarzenie", value: state.lastFeedTime, color: "#94a3b8" },
              ].map(({ label, value, color }) => (
                <div
                  key={label}
                  className="rounded-xl px-3 py-2.5"
                  style={{
                    background: "rgba(255,255,255,0.03)",
                    border: "1px solid rgba(255,255,255,0.06)",
                  }}
                >
                  <p style={{ fontSize: 10, color: "#475569" }}>{label}</p>
                  <p style={{ fontSize: 12, color, marginTop: 2 }}>{value}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Warning */}
          <div
            className="rounded-2xl px-4 py-3.5 flex items-start gap-3"
            style={{
              background: "rgba(251,191,36,0.06)",
              border: "1px solid rgba(251,191,36,0.15)",
            }}
          >
            <AlertCircle size={15} style={{ color: "#fbbf24", flexShrink: 0, marginTop: 1 }} />
            <p style={{ fontSize: 12, color: "#94a3b8" }}>
              Karmnik posiada timeout bezpieczeństwa (15s) oraz czujnik potwierdzenia zakończenia cyklu.
              Wielokrotne nieudane próby są logowane jako zdarzenia WARN w logach systemowych.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}