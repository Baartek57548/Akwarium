import { useState } from "react";
import {
  ScrollText,
  AlertTriangle,
  Info,
  XCircle,
  Trash2,
  CheckCircle2,
  Search,
  Filter,
  DownloadCloud,
} from "lucide-react";
import { useDevice, LogEntry } from "../deviceContext";

function LevelBadge({ level }: { level: LogEntry["level"] }) {
  const cfg = {
    INFO: { color: "#22d3ee", bg: "rgba(34,211,238,0.1)", border: "rgba(34,211,238,0.2)" },
    WARN: { color: "#fbbf24", bg: "rgba(251,191,36,0.1)", border: "rgba(251,191,36,0.2)" },
    ERROR: { color: "#f87171", bg: "rgba(248,113,113,0.1)", border: "rgba(248,113,113,0.2)" },
  }[level];
  const Icon = level === "INFO" ? Info : level === "WARN" ? AlertTriangle : XCircle;
  return (
    <div
      className="inline-flex items-center gap-1 rounded-md px-2 py-0.5"
      style={{ background: cfg.bg, border: `1px solid ${cfg.border}`, minWidth: 56 }}
    >
      <Icon size={10} style={{ color: cfg.color }} />
      <span style={{ fontSize: 10, color: cfg.color, letterSpacing: "0.04em" }}>{level}</span>
    </div>
  );
}

export function Logs() {
  const { state, clearCriticalLogs } = useDevice();
  const [activeTab, setActiveTab] = useState<"normal" | "critical">("normal");
  const [cleared, setCleared] = useState(false);
  const [search, setSearch] = useState("");
  const [filterLevel, setFilterLevel] = useState<"ALL" | "INFO" | "WARN" | "ERROR">("ALL");

  const handleClear = () => {
    clearCriticalLogs();
    setCleared(true);
    setTimeout(() => setCleared(false), 2500);
  };

  const rawLogs = activeTab === "normal" ? state.logs : state.criticalLogs;
  const filtered = rawLogs.filter((l) => {
    const matchLevel = filterLevel === "ALL" || l.level === filterLevel;
    const matchSearch =
      search === "" ||
      l.message.toLowerCase().includes(search.toLowerCase()) ||
      l.timestamp.includes(search);
    return matchLevel && matchSearch;
  });

  const stats = {
    INFO: state.logs.filter((l) => l.level === "INFO").length,
    WARN: state.logs.filter((l) => l.level === "WARN").length,
    ERROR: state.logs.filter((l) => l.level === "ERROR").length,
  };

  return (
    <div style={{ minHeight: "100%", color: "#e2e8f0" }}>
      {/* Header */}
      <div
        className="flex items-center justify-between px-8 py-5"
        style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}
      >
        <div>
          <h1 style={{ fontSize: 20, color: "#f1f5f9" }}>Logi systemowe</h1>
          <p style={{ fontSize: 12, color: "#64748b", marginTop: 1 }}>
            Ring buffer · 20 wpisów RAM + trwałe logi krytyczne w Preferences (Flash)
          </p>
        </div>
        <div className="flex items-center gap-3">
          {activeTab === "critical" && state.criticalLogs.length > 0 && (
            <button
              onClick={handleClear}
              className="flex items-center gap-2 rounded-xl px-4 py-2 transition-all hover:scale-[1.02] active:scale-95"
              style={{
                background: cleared ? "rgba(74,222,128,0.12)" : "rgba(248,113,113,0.1)",
                border: `1px solid ${cleared ? "rgba(74,222,128,0.3)" : "rgba(248,113,113,0.25)"}`,
                color: cleared ? "#4ade80" : "#f87171",
              }}
            >
              {cleared ? <CheckCircle2 size={14} /> : <Trash2 size={14} />}
              <span style={{ fontSize: 13 }}>{cleared ? "Wyczyszczono!" : "Wyczyść logi krytyczne"}</span>
            </button>
          )}
          <button
            className="flex items-center gap-2 rounded-xl px-4 py-2 transition-all hover:bg-white/5"
            style={{
              border: "1px solid rgba(255,255,255,0.08)",
              color: "#64748b",
            }}
          >
            <DownloadCloud size={14} />
            <span style={{ fontSize: 13 }}>Eksportuj</span>
          </button>
        </div>
      </div>

      <div className="p-8 flex flex-col gap-5">
        {/* Stats */}
        <div className="grid grid-cols-4 gap-4">
          {[
            {
              label: "Wszystkich logów",
              value: state.logs.length,
              color: "#94a3b8",
              bg: "rgba(255,255,255,0.03)",
              border: "rgba(255,255,255,0.07)",
            },
            {
              label: "INFO",
              value: stats.INFO,
              color: "#22d3ee",
              bg: "rgba(34,211,238,0.06)",
              border: "rgba(34,211,238,0.15)",
            },
            {
              label: "WARN",
              value: stats.WARN,
              color: "#fbbf24",
              bg: "rgba(251,191,36,0.06)",
              border: "rgba(251,191,36,0.15)",
            },
            {
              label: "Krytycznych (Flash)",
              value: state.criticalLogs.length,
              color: state.criticalLogs.length > 0 ? "#f87171" : "#475569",
              bg: state.criticalLogs.length > 0 ? "rgba(248,113,113,0.06)" : "rgba(255,255,255,0.03)",
              border: state.criticalLogs.length > 0 ? "rgba(248,113,113,0.15)" : "rgba(255,255,255,0.07)",
            },
          ].map(({ label, value, color, bg, border }) => (
            <div
              key={label}
              className="rounded-2xl p-4"
              style={{ background: bg, border: `1px solid ${border}` }}
            >
              <p style={{ fontSize: 28, color, letterSpacing: "-0.03em" }}>{value}</p>
              <p style={{ fontSize: 12, color: "#64748b", marginTop: 2 }}>{label}</p>
            </div>
          ))}
        </div>

        {/* Main log panel */}
        <div
          className="rounded-2xl overflow-hidden"
          style={{
            background: "rgba(255,255,255,0.02)",
            border: "1px solid rgba(255,255,255,0.07)",
          }}
        >
          {/* Toolbar */}
          <div
            className="flex items-center gap-3 px-4 py-3"
            style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}
          >
            {/* Tabs */}
            <div
              className="flex rounded-xl p-0.5 gap-0.5"
              style={{ background: "rgba(255,255,255,0.04)" }}
            >
              <button
                onClick={() => setActiveTab("normal")}
                className="flex items-center gap-2 rounded-lg px-3 py-1.5 transition-all"
                style={{
                  background: activeTab === "normal" ? "rgba(34,211,238,0.12)" : "transparent",
                  border: activeTab === "normal" ? "1px solid rgba(34,211,238,0.2)" : "1px solid transparent",
                  color: activeTab === "normal" ? "#22d3ee" : "#6b7280",
                  fontSize: 12,
                }}
              >
                <ScrollText size={13} />
                Bieżące ({state.logs.length})
              </button>
              <button
                onClick={() => setActiveTab("critical")}
                className="flex items-center gap-2 rounded-lg px-3 py-1.5 transition-all"
                style={{
                  background: activeTab === "critical" ? "rgba(248,113,113,0.12)" : "transparent",
                  border: activeTab === "critical" ? "1px solid rgba(248,113,113,0.2)" : "1px solid transparent",
                  color: activeTab === "critical" ? "#f87171" : "#6b7280",
                  fontSize: 12,
                }}
              >
                <AlertTriangle size={13} />
                Krytyczne ({state.criticalLogs.length})
              </button>
            </div>

            <div style={{ flex: 1 }} />

            {/* Level filter */}
            <div className="flex items-center gap-1.5">
              <Filter size={12} style={{ color: "#64748b" }} />
              <div className="flex gap-1">
                {(["ALL", "INFO", "WARN", "ERROR"] as const).map((lvl) => {
                  const color =
                    lvl === "ALL" ? "#94a3b8" : lvl === "INFO" ? "#22d3ee" : lvl === "WARN" ? "#fbbf24" : "#f87171";
                  return (
                    <button
                      key={lvl}
                      onClick={() => setFilterLevel(lvl)}
                      className="rounded-lg px-2.5 py-1 transition-all"
                      style={{
                        background: filterLevel === lvl ? `${color}18` : "rgba(255,255,255,0.03)",
                        border: `1px solid ${filterLevel === lvl ? color + "35" : "rgba(255,255,255,0.06)"}`,
                        color: filterLevel === lvl ? color : "#6b7280",
                        fontSize: 11,
                      }}
                    >
                      {lvl}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Search */}
            <div
              className="flex items-center gap-2 rounded-xl px-3 py-1.5"
              style={{
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.08)",
              }}
            >
              <Search size={13} style={{ color: "#64748b" }} />
              <input
                type="text"
                placeholder="Szukaj..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="outline-none bg-transparent"
                style={{ fontSize: 12, color: "#e2e8f0", width: 140 }}
              />
            </div>
          </div>

          {/* Table header */}
          <div
            className="grid px-4 py-2"
            style={{
              gridTemplateColumns: "70px 130px 1fr",
              borderBottom: "1px solid rgba(255,255,255,0.05)",
              background: "rgba(255,255,255,0.02)",
            }}
          >
            {["Poziom", "Czas", "Wiadomość"].map((h) => (
              <span key={h} style={{ fontSize: 10, color: "#475569", letterSpacing: "0.06em" }} className="uppercase">
                {h}
              </span>
            ))}
          </div>

          {/* Rows */}
          <div style={{ maxHeight: 460, overflowY: "auto" }}>
            {filtered.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 gap-3">
                <CheckCircle2 size={36} style={{ color: "#4ade80", opacity: 0.4 }} />
                <p style={{ fontSize: 14, color: "#475569" }}>Brak pasujących wpisów</p>
              </div>
            ) : (
              filtered.map((log, i) => {
                const levelColor =
                  log.level === "INFO" ? "#22d3ee" : log.level === "WARN" ? "#fbbf24" : "#f87171";
                return (
                  <div
                    key={log.id}
                    className="grid px-4 py-2.5 transition-colors hover:bg-white/[0.02]"
                    style={{
                      gridTemplateColumns: "70px 130px 1fr",
                      borderBottom: "1px solid rgba(255,255,255,0.03)",
                      background: i % 2 === 0 ? "transparent" : "rgba(255,255,255,0.01)",
                    }}
                  >
                    <LevelBadge level={log.level} />
                    <span
                      style={{
                        fontSize: 12,
                        color: "#64748b",
                        fontVariantNumeric: "tabular-nums",
                        alignSelf: "center",
                      }}
                    >
                      {log.timestamp}
                    </span>
                    <span style={{ fontSize: 13, color: "#cbd5e1", alignSelf: "center" }}>
                      {log.message}
                    </span>
                  </div>
                );
              })
            )}
          </div>

          {/* Footer */}
          <div
            className="flex items-center justify-between px-4 py-2.5"
            style={{ borderTop: "1px solid rgba(255,255,255,0.05)" }}
          >
            <span style={{ fontSize: 11, color: "#475569" }}>
              {filtered.length} z {rawLogs.length} wpisów
            </span>
            {activeTab === "critical" && (
              <span style={{ fontSize: 11, color: "#64748b" }}>
                API: <span style={{ color: "#f87171" }}>POST /api/action</span>{" "}
                z <span style={{ color: "#fbbf24" }}>action=clear_critical_logs</span>
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
