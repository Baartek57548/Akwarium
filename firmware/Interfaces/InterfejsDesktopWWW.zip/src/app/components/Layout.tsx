import { NavLink, Outlet } from "react-router";
import {
  LayoutDashboard,
  CalendarClock,
  Fish,
  ScrollText,
  Settings2,
  Waves,
  Wifi,
  WifiOff,
  Circle,
} from "lucide-react";
import { useDevice } from "../deviceContext";

const navItems = [
  { to: "/", label: "Panel główny", icon: LayoutDashboard },
  { to: "/schedule", label: "Harmonogram", icon: CalendarClock },
  { to: "/feeder", label: "Karmnik", icon: Fish },
  { to: "/logs", label: "Logi systemowe", icon: ScrollText },
  { to: "/settings", label: "Ustawienia", icon: Settings2 },
];

export function Layout() {
  const { state } = useDevice();

  return (
    <div
      className="flex min-h-screen"
      style={{ background: "#07091a", color: "#e2e8f0" }}
    >
      {/* Sidebar */}
      <aside
        className="flex flex-col shrink-0"
        style={{
          width: 240,
          background: "rgba(8,12,28,0.98)",
          borderRight: "1px solid rgba(6,182,212,0.1)",
          position: "sticky",
          top: 0,
          height: "100vh",
          overflowY: "auto",
        }}
      >
        {/* Logo */}
        <div
          className="flex items-center gap-3 px-5 py-5"
          style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}
        >
          <div
            className="flex items-center justify-center rounded-xl"
            style={{
              width: 38,
              height: 38,
              background: "linear-gradient(135deg, rgba(6,182,212,0.3), rgba(6,182,212,0.1))",
              border: "1px solid rgba(6,182,212,0.4)",
              boxShadow: "0 0 14px rgba(6,182,212,0.2)",
            }}
          >
            <Waves size={18} style={{ color: "#22d3ee" }} />
          </div>
          <div>
            <p style={{ fontSize: 13, color: "#e2e8f0", lineHeight: 1.2 }}>Sterownik</p>
            <p style={{ fontSize: 11, color: "#22d3ee", lineHeight: 1.2, letterSpacing: "0.05em" }}>
              Akwarium PRO
            </p>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex flex-col gap-1 px-3 py-4 flex-1">
          <p
            style={{ fontSize: 10, color: "#475569", letterSpacing: "0.1em", paddingLeft: 10, marginBottom: 4 }}
            className="uppercase"
          >
            Menu
          </p>
          {navItems.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              end={to === "/"}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all ${
                  isActive ? "text-cyan-300" : "text-slate-400 hover:text-slate-200"
                }`
              }
              style={({ isActive }) => ({
                background: isActive
                  ? "linear-gradient(90deg, rgba(6,182,212,0.15), rgba(6,182,212,0.05))"
                  : "transparent",
                border: isActive ? "1px solid rgba(6,182,212,0.2)" : "1px solid transparent",
              })}
            >
              {({ isActive }) => (
                <>
                  <Icon
                    size={16}
                    style={{
                      color: isActive ? "#22d3ee" : "#64748b",
                      filter: isActive ? "drop-shadow(0 0 4px rgba(34,211,238,0.5))" : "none",
                    }}
                  />
                  <span style={{ fontSize: 13 }}>{label}</span>
                </>
              )}
            </NavLink>
          ))}
        </nav>

        {/* Status footer */}
        <div
          className="px-4 py-4 flex flex-col gap-2"
          style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }}
        >
          <div className="flex items-center gap-2">
            {state.wifi.connected ? (
              <>
                <Wifi size={13} style={{ color: "#22d3ee" }} />
                <span style={{ fontSize: 11, color: "#94a3b8" }}>
                  {state.wifi.ssid} · {state.wifi.ip}
                </span>
              </>
            ) : (
              <>
                <WifiOff size={13} style={{ color: "#6b7280" }} />
                <span style={{ fontSize: 11, color: "#6b7280" }}>Offline</span>
              </>
            )}
          </div>
          <div className="flex items-center gap-2">
            <Circle
              size={7}
              style={{
                color: "#4ade80",
                fill: "#4ade80",
                filter: "drop-shadow(0 0 4px rgba(74,222,128,0.7))",
              }}
            />
            <span style={{ fontSize: 11, color: "#94a3b8" }}>
              ESP32-S3 · uptime {state.uptime}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span style={{ fontSize: 10, color: "#475569" }}>v5.1 · ESP32-S3-DevKitC</span>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-auto">
        <Outlet />
      </main>
    </div>
  );
}
