import { NavLink, Outlet } from "react-router";
import {
  LayoutDashboard,
  CalendarClock,
  Fish,
  ScrollText,
  Settings2,
  Waves,
  Wifi,
  WifiOff,
} from "lucide-react";
import { useDevice } from "../deviceContext";

const navItems = [
  { to: "/", label: "Panel", icon: LayoutDashboard },
  { to: "/schedule", label: "Harmonogram", icon: CalendarClock },
  { to: "/feeder", label: "Karmnik", icon: Fish },
  { to: "/logs", label: "Logi", icon: ScrollText },
  { to: "/settings", label: "Ustawienia", icon: Settings2 },
];

export function Layout() {
  const { state } = useDevice();

  return (
    <div
      className="flex flex-col min-h-screen"
      style={{ background: "#07091a", color: "#e2e8f0" }}
    >
      {/* Top status bar */}
      <header
        className="flex items-center justify-between px-4 py-3 shrink-0"
        style={{
          background: "rgba(8,12,28,0.98)",
          borderBottom: "1px solid rgba(6,182,212,0.1)",
        }}
      >
        <div className="flex items-center gap-2.5">
          <div
            className="flex items-center justify-center rounded-xl"
            style={{
              width: 32,
              height: 32,
              background: "linear-gradient(135deg, rgba(6,182,212,0.3), rgba(6,182,212,0.1))",
              border: "1px solid rgba(6,182,212,0.4)",
              boxShadow: "0 0 10px rgba(6,182,212,0.2)",
            }}
          >
            <Waves size={15} style={{ color: "#22d3ee" }} />
          </div>
          <div>
            <p style={{ fontSize: 13, color: "#e2e8f0", lineHeight: 1.2 }}>Sterownik</p>
            <p style={{ fontSize: 10, color: "#22d3ee", lineHeight: 1.2, letterSpacing: "0.05em" }}>
              Akwarium PRO
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {state.wifi.connected ? (
            <div className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5" style={{ background: "rgba(34,211,238,0.08)", border: "1px solid rgba(34,211,238,0.15)" }}>
              <div style={{ width: 6, height: 6, borderRadius: "50%", background: "#4ade80", boxShadow: "0 0 5px #4ade80" }} />
              <span style={{ fontSize: 10, color: "#94a3b8" }}>{state.wifi.ip}</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5" style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}>
              <WifiOff size={11} style={{ color: "#6b7280" }} />
              <span style={{ fontSize: 10, color: "#6b7280" }}>Offline</span>
            </div>
          )}
        </div>
      </header>

      {/* Page content */}
      <main className="flex-1 overflow-auto pb-20">
        <Outlet />
      </main>

      {/* Bottom navigation */}
      <nav
        className="fixed bottom-0 left-0 right-0 flex items-stretch"
        style={{
          background: "rgba(8,12,28,0.97)",
          borderTop: "1px solid rgba(6,182,212,0.1)",
          backdropFilter: "blur(12px)",
          zIndex: 50,
        }}
      >
        {navItems.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            end={to === "/"}
            className="flex-1"
          >
            {({ isActive }) => (
              <div
                className="flex flex-col items-center justify-center gap-1 py-2.5"
                style={{
                  color: isActive ? "#22d3ee" : "#475569",
                }}
              >
                <Icon
                  size={20}
                  style={{
                    color: isActive ? "#22d3ee" : "#475569",
                    filter: isActive ? "drop-shadow(0 0 5px rgba(34,211,238,0.6))" : "none",
                    transition: "all 0.2s",
                  }}
                />
                <span
                  style={{
                    fontSize: 9,
                    letterSpacing: "0.02em",
                    color: isActive ? "#22d3ee" : "#475569",
                    transition: "color 0.2s",
                  }}
                >
                  {label}
                </span>
                {isActive && (
                  <div
                    style={{
                      position: "absolute",
                      bottom: 0,
                      width: 24,
                      height: 2,
                      background: "#22d3ee",
                      borderRadius: "2px 2px 0 0",
                      boxShadow: "0 0 6px #22d3ee",
                    }}
                  />
                )}
              </div>
            )}
          </NavLink>
        ))}
      </nav>
    </div>
  );
}
