import { useState } from "react";
import {
  Thermometer,
  Wifi,
  WifiOff,
  Radio,
  Sliders,
  Monitor,
  Upload,
  RefreshCw,
  Save,
  Check,
  Moon,
  Sun,
  AlertCircle,
  Cpu,
  Wind,
  Info,
  Shield,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { useDevice } from "../deviceContext";

function SectionCard({
  title,
  icon: Icon,
  color,
  children,
  defaultOpen = true,
}: {
  title: string;
  icon: React.ElementType;
  color: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div
      className="rounded-2xl overflow-hidden"
      style={{
        background: "rgba(255,255,255,0.025)",
        border: "1px solid rgba(255,255,255,0.07)",
      }}
    >
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between px-4 py-3.5 transition-all active:bg-white/[0.02]"
        style={{ borderBottom: open ? "1px solid rgba(255,255,255,0.06)" : "none" }}
      >
        <div className="flex items-center gap-3">
          <div className="rounded-xl p-1.5" style={{ background: `${color}18` }}>
            <Icon size={14} style={{ color }} />
          </div>
          <h2 style={{ fontSize: 14, color: "#94a3b8" }}>{title}</h2>
        </div>
        {open ? (
          <ChevronUp size={15} style={{ color: "#475569" }} />
        ) : (
          <ChevronDown size={15} style={{ color: "#475569" }} />
        )}
      </button>
      {open && <div className="p-4">{children}</div>}
    </div>
  );
}

export function Settings() {
  const {
    state,
    setTemp,
    toggleAP,
    setAlwaysScreenOn,
    setServoPreOffMins,
    setManualServo,
    addLog,
  } = useDevice();

  const [targetTemp, setTargetTempLocal] = useState(state.targetTemp.toFixed(1));
  const [hysteresis, setHysteresisLocal] = useState(state.hysteresis.toFixed(1));
  const [tempSaved, setTempSaved] = useState(false);

  const [servoAngle, setServoAngleLocal] = useState(45);
  const [servoPreOff, setServoPreOffLocal] = useState(state.servoPreOffMins);
  const [servoSaved, setServoSaved] = useState(false);

  const [syncingTime, setSyncingTime] = useState(false);
  const [timeSynced, setTimeSynced] = useState(false);

  const handleTempSave = () => {
    const t = parseFloat(targetTemp);
    const h = parseFloat(hysteresis);
    if (!isNaN(t) && !isNaN(h)) {
      setTemp(t, h);
      setTempSaved(true);
      setTimeout(() => setTempSaved(false), 2500);
    }
  };

  const handleServoSave = () => {
    setServoPreOffMins(servoPreOff);
    setServoSaved(true);
    setTimeout(() => setServoSaved(false), 2500);
  };

  const handleTimeSync = () => {
    setSyncingTime(true);
    setTimeout(() => {
      setSyncingTime(false);
      setTimeSynced(true);
      addLog("INFO", "Czas zsynchronizowany z urządzeniem klienta");
      setTimeout(() => setTimeSynced(false), 3000);
    }, 1500);
  };

  const rssiColor =
    state.wifi.rssi > -60 ? "#4ade80" : state.wifi.rssi > -75 ? "#fbbf24" : "#f87171";

  return (
    <div style={{ minHeight: "100%", color: "#e2e8f0" }}>
      {/* Header */}
      <div className="px-4 pt-4 pb-3">
        <h1 style={{ fontSize: 18, color: "#f1f5f9" }}>Ustawienia</h1>
        <p style={{ fontSize: 11, color: "#64748b", marginTop: 1 }}>
          Konfiguracja ESP32-S3 · v5.1
        </p>
      </div>

      <div className="px-4 pb-4 flex flex-col gap-3">
        {/* Temperature */}
        <SectionCard title="Temperatura i grzałka" icon={Thermometer} color="#fb7185">
          <div className="grid grid-cols-2 gap-3 mb-4">
            <div className="flex flex-col gap-2">
              <label style={{ fontSize: 12, color: "#94a3b8" }}>Temperatura docelowa (°C)</label>
              <input
                type="number"
                step="0.1"
                min="18"
                max="30"
                value={targetTemp}
                onChange={(e) => setTargetTempLocal(e.target.value)}
                className="rounded-xl px-3 py-2.5 outline-none"
                style={{
                  background: "rgba(255,255,255,0.05)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  color: "#fb7185",
                  fontSize: 14,
                  colorScheme: "dark",
                }}
              />
            </div>
            <div className="flex flex-col gap-2">
              <label style={{ fontSize: 12, color: "#94a3b8" }}>Histereza (°C)</label>
              <input
                type="number"
                step="0.1"
                min="0.1"
                max="2"
                value={hysteresis}
                onChange={(e) => setHysteresisLocal(e.target.value)}
                className="rounded-xl px-3 py-2.5 outline-none"
                style={{
                  background: "rgba(255,255,255,0.05)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  color: "#fb7185",
                  fontSize: 14,
                  colorScheme: "dark",
                }}
              />
            </div>
          </div>

          <div
            className="rounded-xl px-3 py-2.5 mb-4 flex items-center gap-2"
            style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.18)" }}
          >
            <Shield size={12} style={{ color: "#f87171" }} />
            <span style={{ fontSize: 11, color: "#94a3b8" }}>
              Limit awaryjny: <span style={{ color: "#f87171" }}>28.0°C</span> — fail-safe
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2 mb-4">
            {[
              { label: "Aktualna", value: `${state.currentTemp.toFixed(1)}°C`, color: "#22d3ee" },
              { label: "Docelowa", value: `${parseFloat(targetTemp).toFixed(1)}°C`, color: "#fb7185" },
              { label: "Grzałka", value: state.heaterOn ? "ON" : "OFF", color: state.heaterOn ? "#fb923c" : "#4b5563" },
            ].map(({ label, value, color }) => (
              <div
                key={label}
                className="rounded-xl p-2.5 text-center"
                style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}
              >
                <p style={{ fontSize: 15, color }}>{value}</p>
                <p style={{ fontSize: 10, color: "#64748b", marginTop: 2 }}>{label}</p>
              </div>
            ))}
          </div>

          <button
            onClick={handleTempSave}
            className="w-full flex items-center justify-center gap-2 rounded-xl py-3 transition-all active:scale-95"
            style={{
              background: tempSaved ? "rgba(74,222,128,0.12)" : "rgba(251,113,133,0.1)",
              border: `1px solid ${tempSaved ? "rgba(74,222,128,0.3)" : "rgba(251,113,133,0.25)"}`,
              color: tempSaved ? "#4ade80" : "#fb7185",
              cursor: "pointer",
            }}
          >
            {tempSaved ? <Check size={15} /> : <Save size={15} />}
            <span style={{ fontSize: 13 }}>{tempSaved ? "Zapisano!" : "Zapisz ustawienia temperatury"}</span>
          </button>
        </SectionCard>

        {/* Servo */}
        <SectionCard title="Serwo napowietrzania (GPIO6)" icon={Wind} color="#34d399">
          <div className="flex flex-col gap-4">
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <label style={{ fontSize: 12, color: "#94a3b8" }}>Ręczny kąt serwa</label>
                <span style={{ fontSize: 14, color: "#34d399" }}>{servoAngle}°</span>
              </div>
              <input
                type="range"
                min="0"
                max="90"
                value={servoAngle}
                onChange={(e) => setServoAngleLocal(Number(e.target.value))}
                className="w-full"
                style={{ accentColor: "#34d399" }}
              />
              <div className="flex justify-between">
                <span style={{ fontSize: 10, color: "#475569" }}>0° (wyłączone)</span>
                <span style={{ fontSize: 10, color: "#475569" }}>90° (maks.)</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setManualServo(servoAngle)}
                className="flex items-center justify-center gap-2 rounded-xl py-2.5 transition-all active:scale-95"
                style={{
                  background: "rgba(52,211,153,0.1)",
                  border: "1px solid rgba(52,211,153,0.25)",
                  color: "#34d399",
                  fontSize: 13,
                  cursor: "pointer",
                }}
              >
                <Sliders size={13} />
                Ustaw {servoAngle}°
              </button>
              <button
                onClick={() => setManualServo(null)}
                className="flex items-center justify-center gap-2 rounded-xl py-2.5 transition-all active:scale-95"
                style={{
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.08)",
                  color: "#6b7280",
                  fontSize: 13,
                  cursor: "pointer",
                }}
              >
                Wyczyść
              </button>
            </div>

            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <label style={{ fontSize: 12, color: "#94a3b8" }}>Pre-off przed końcem</label>
                <span style={{ fontSize: 14, color: "#34d399" }}>{servoPreOff} min</span>
              </div>
              <input
                type="range"
                min="5"
                max="60"
                step="5"
                value={servoPreOff}
                onChange={(e) => setServoPreOffLocal(Number(e.target.value))}
                style={{ accentColor: "#34d399" }}
                className="w-full"
              />
            </div>

            <div
              className="rounded-xl px-3 py-2 flex items-start gap-2"
              style={{ background: "rgba(52,211,153,0.06)", border: "1px solid rgba(52,211,153,0.15)" }}
            >
              <Info size={11} style={{ color: "#34d399", marginTop: 2, flexShrink: 0 }} />
              <span style={{ fontSize: 11, color: "#64748b" }}>
                Ręczny override serwa wygasa po 5 min. Attach tylko na czas ruchu.
              </span>
            </div>

            <button
              onClick={handleServoSave}
              className="w-full flex items-center justify-center gap-2 rounded-xl py-3 transition-all active:scale-95"
              style={{
                background: servoSaved ? "rgba(74,222,128,0.12)" : "rgba(52,211,153,0.1)",
                border: `1px solid ${servoSaved ? "rgba(74,222,128,0.3)" : "rgba(52,211,153,0.2)"}`,
                color: servoSaved ? "#4ade80" : "#34d399",
                cursor: "pointer",
              }}
            >
              {servoSaved ? <Check size={15} /> : <Save size={15} />}
              <span style={{ fontSize: 13 }}>{servoSaved ? "Zapisano!" : "Zapisz ustawienia serwa"}</span>
            </button>
          </div>
        </SectionCard>

        {/* WiFi */}
        <SectionCard title="Sieć WiFi" icon={Wifi} color="#38bdf8">
          <div className="flex flex-col gap-3">
            <div
              className="rounded-xl p-3 flex items-center gap-3"
              style={{
                background: state.wifi.connected ? "rgba(56,189,248,0.06)" : "rgba(255,255,255,0.03)",
                border: `1px solid ${state.wifi.connected ? "rgba(56,189,248,0.2)" : "rgba(255,255,255,0.07)"}`,
              }}
            >
              {state.wifi.connected ? (
                <Wifi size={17} style={{ color: "#38bdf8" }} />
              ) : (
                <WifiOff size={17} style={{ color: "#6b7280" }} />
              )}
              <div className="flex-1 min-w-0">
                <p style={{ fontSize: 13, color: "#e2e8f0" }}>
                  {state.wifi.connected ? state.wifi.ssid : "Rozłączono"}
                </p>
                <p style={{ fontSize: 11, color: "#64748b" }}>
                  {state.wifi.connected ? `IP: ${state.wifi.ip}` : "Tryb offline"}
                </p>
              </div>
              {state.wifi.connected && (
                <div className="text-right shrink-0">
                  <p style={{ fontSize: 13, color: rssiColor }}>{state.wifi.rssi} dBm</p>
                  <p style={{ fontSize: 10, color: "#475569" }}>RSSI</p>
                </div>
              )}
            </div>

            <div
              className="rounded-xl p-3 flex items-center gap-3"
              style={{
                background: state.wifi.apActive ? "rgba(56,189,248,0.08)" : "rgba(255,255,255,0.02)",
                border: `1px solid ${state.wifi.apActive ? "rgba(56,189,248,0.25)" : "rgba(255,255,255,0.06)"}`,
              }}
            >
              <Radio size={16} style={{ color: state.wifi.apActive ? "#38bdf8" : "#4b5563" }} />
              <div className="flex-1 min-w-0">
                <p style={{ fontSize: 13, color: state.wifi.apActive ? "#e2e8f0" : "#6b7280" }}>
                  Access Point (AP)
                </p>
                <p style={{ fontSize: 11, color: "#64748b" }}>
                  {state.wifi.apActive
                    ? `${state.wifi.apSsid} · ${state.wifi.apIp}`
                    : "Wyłączony"}
                </p>
              </div>
              <button
                onClick={toggleAP}
                className="flex items-center justify-center rounded-lg px-3 py-2 transition-all active:scale-95 shrink-0"
                style={{
                  background: state.wifi.apActive ? "rgba(248,113,113,0.12)" : "rgba(56,189,248,0.1)",
                  border: `1px solid ${state.wifi.apActive ? "rgba(248,113,113,0.3)" : "rgba(56,189,248,0.25)"}`,
                  color: state.wifi.apActive ? "#f87171" : "#38bdf8",
                  fontSize: 12,
                  cursor: "pointer",
                }}
              >
                {state.wifi.apActive ? "Wyłącz" : "Uruchom"}
              </button>
            </div>

            <div
              className="rounded-xl px-3 py-2 flex items-start gap-2"
              style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}
            >
              <Info size={11} style={{ color: "#64748b", marginTop: 2, flexShrink: 0 }} />
              <span style={{ fontSize: 11, color: "#64748b" }}>
                Łączy w trybie STA przez 6s, po timeout działa offline. AP uruchamia się tylko ręcznie.
              </span>
            </div>
          </div>
        </SectionCard>

        {/* Display */}
        <SectionCard title="Wyświetlacz OLED i sleep" icon={Monitor} color="#a78bfa">
          <div className="flex flex-col gap-3">
            <div
              className="flex items-center justify-between rounded-xl p-3"
              style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}
            >
              <div className="flex-1 mr-3">
                <p style={{ fontSize: 13, color: "#e2e8f0" }}>Zawsze włączony ekran</p>
                <p style={{ fontSize: 11, color: "#64748b", marginTop: 1 }}>
                  Wyłącz, by oszczędzać energię
                </p>
              </div>
              <button
                onClick={() => setAlwaysScreenOn(!state.alwaysScreenOn)}
                className="relative flex items-center rounded-full transition-all shrink-0"
                style={{
                  width: 48,
                  height: 26,
                  background: state.alwaysScreenOn ? "rgba(167,139,250,0.3)" : "rgba(255,255,255,0.08)",
                  border: `1px solid ${state.alwaysScreenOn ? "rgba(167,139,250,0.5)" : "rgba(255,255,255,0.1)"}`,
                  padding: "0 3px",
                  cursor: "pointer",
                }}
              >
                <div
                  className="rounded-full transition-all"
                  style={{
                    width: 20,
                    height: 20,
                    background: state.alwaysScreenOn ? "#a78bfa" : "#475569",
                    transform: state.alwaysScreenOn ? "translateX(20px)" : "translateX(0)",
                    boxShadow: state.alwaysScreenOn ? "0 0 8px rgba(167,139,250,0.7)" : "none",
                  }}
                />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {[
                {
                  icon: Moon,
                  label: "Power-save",
                  value: "po 4 min",
                  color: "#94a3b8",
                  active: !state.alwaysScreenOn,
                },
                {
                  icon: Sun,
                  label: "Deep Sleep",
                  value: state.alwaysScreenOn ? "Wyłączony" : "po 5 min",
                  color: state.alwaysScreenOn ? "#4b5563" : "#a78bfa",
                  active: !state.alwaysScreenOn,
                },
              ].map(({ icon: Icon, label, value, color, active }) => (
                <div
                  key={label}
                  className="rounded-xl p-3"
                  style={{
                    background: "rgba(255,255,255,0.03)",
                    border: "1px solid rgba(255,255,255,0.06)",
                    opacity: active ? 1 : 0.5,
                  }}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Icon size={12} style={{ color }} />
                    <p style={{ fontSize: 12, color: "#94a3b8" }}>{label}</p>
                  </div>
                  <p style={{ fontSize: 12, color }}>{value}</p>
                </div>
              ))}
            </div>
          </div>
        </SectionCard>

        {/* Time sync */}
        <SectionCard title="Synchronizacja czasu RTC" icon={RefreshCw} color="#fbbf24" defaultOpen={false}>
          <div className="flex flex-col gap-3">
            <p style={{ fontSize: 12, color: "#64748b" }}>
              Wysyła aktualny czas UNIX z przeglądarki do ESP32 przez{" "}
              <span style={{ color: "#fbbf24" }}>POST /settime?epoch=&lt;unix&gt;</span>.
            </p>
            <div
              className="rounded-xl p-3"
              style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}
            >
              <p style={{ fontSize: 11, color: "#64748b" }}>Aktualny czas</p>
              <p style={{ fontSize: 14, color: "#fbbf24" }}>{new Date().toLocaleString("pl-PL")}</p>
              <p style={{ fontSize: 10, color: "#475569", marginTop: 2 }}>
                UNIX: {Math.floor(Date.now() / 1000)}
              </p>
            </div>
            <button
              onClick={handleTimeSync}
              disabled={syncingTime}
              className="w-full flex items-center justify-center gap-2 rounded-xl py-3 transition-all active:scale-95"
              style={{
                background: timeSynced ? "rgba(74,222,128,0.12)" : "rgba(251,191,36,0.1)",
                border: `1px solid ${timeSynced ? "rgba(74,222,128,0.3)" : "rgba(251,191,36,0.25)"}`,
                color: timeSynced ? "#4ade80" : "#fbbf24",
                cursor: "pointer",
              }}
            >
              {timeSynced ? (
                <Check size={15} />
              ) : (
                <RefreshCw size={15} className={syncingTime ? "animate-spin" : ""} />
              )}
              <span style={{ fontSize: 13 }}>
                {timeSynced ? "Zsynchronizowano!" : syncingTime ? "Synchronizuję..." : "Synchronizuj czas RTC"}
              </span>
            </button>
          </div>
        </SectionCard>

        {/* OTA */}
        <SectionCard title="Aktualizacja OTA firmware" icon={Upload} color="#c084fc" defaultOpen={false}>
          <div className="flex flex-col gap-3">
            <p style={{ fontSize: 12, color: "#64748b" }}>
              Prześlij plik <span style={{ color: "#c084fc" }}>.bin</span> z PlatformIO.
              Endpoint: <span style={{ color: "#c084fc" }}>POST /update</span>.
            </p>
            <label
              className="flex flex-col items-center justify-center gap-3 rounded-xl py-8 cursor-pointer transition-all"
              style={{
                background: "rgba(192,132,252,0.05)",
                border: "2px dashed rgba(192,132,252,0.25)",
              }}
            >
              <Upload size={22} style={{ color: "#c084fc", opacity: 0.6 }} />
              <div className="text-center">
                <p style={{ fontSize: 13, color: "#c084fc" }}>Kliknij lub przeciągnij plik</p>
                <p style={{ fontSize: 11, color: "#64748b" }}>firmware.bin · PlatformIO</p>
              </div>
              <input type="file" accept=".bin" className="hidden" />
            </label>
            <div
              className="rounded-xl px-3 py-2.5 flex items-start gap-2"
              style={{ background: "rgba(251,191,36,0.07)", border: "1px solid rgba(251,191,36,0.15)" }}
            >
              <AlertCircle size={12} style={{ color: "#fbbf24", marginTop: 1, flexShrink: 0 }} />
              <span style={{ fontSize: 11, color: "#94a3b8" }}>
                OTA blokuje Deep Sleep. Nie przerywaj zasilania. Komenda:{" "}
                <span style={{ color: "#fbbf24" }}>pio run -t upload</span>
              </span>
            </div>
          </div>
        </SectionCard>

        {/* System info */}
        <div
          className="rounded-2xl overflow-hidden"
          style={{
            background: "rgba(255,255,255,0.025)",
            border: "1px solid rgba(255,255,255,0.07)",
          }}
        >
          <div
            className="flex items-center gap-3 px-4 py-3.5"
            style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}
          >
            <div className="rounded-xl p-1.5" style={{ background: "rgba(100,116,139,0.15)" }}>
              <Cpu size={14} style={{ color: "#64748b" }} />
            </div>
            <h2 style={{ fontSize: 14, color: "#94a3b8" }}>Informacje systemowe</h2>
          </div>
          <div className="p-4 grid grid-cols-2 gap-2">
            {[
              { label: "Firmware", value: "v5.1" },
              { label: "Platforma", value: "ESP32-S3-DevKitC-1" },
              { label: "Framework", value: "Arduino / FreeRTOS" },
              { label: "Czas pracy", value: state.uptime },
              { label: "Czujnik temp.", value: "DS18B20 · GPIO1" },
              { label: "Logi RAM", value: "ring buffer · 20" },
              { label: "Logi Flash", value: "Preferences · 20" },
              { label: "WiFi timeout", value: "6s → offline" },
              { label: "API status", value: "GET /api/status" },
              { label: "API logi", value: "GET /api/logs" },
              { label: "API akcje", value: "POST /api/action" },
              { label: "Piny przycisków", value: "GPIO14/15/16" },
            ].map(({ label, value }) => (
              <div
                key={label}
                className="rounded-xl px-3 py-2"
                style={{
                  background: "rgba(255,255,255,0.02)",
                  border: "1px solid rgba(255,255,255,0.05)",
                }}
              >
                <p style={{ fontSize: 10, color: "#475569" }}>{label}</p>
                <p style={{ fontSize: 11, color: "#94a3b8", marginTop: 1 }}>{value}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
