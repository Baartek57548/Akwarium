import { useState } from "react";
import {
  Lightbulb,
  Filter,
  Wind,
  Fish,
  Save,
  Check,
  Clock,
  ToggleLeft,
  ToggleRight,
  Info,
} from "lucide-react";
import { useDevice, DeviceState } from "../deviceContext";

type DeviceKey = "light" | "aeration" | "filter";

const deviceConfigs = [
  {
    key: "light" as DeviceKey,
    label: "Światło",
    icon: Lightbulb,
    color: "#fbbf24",
    pin: "GPIO17",
    note: "Logika odwrotna: LOW = ON",
  },
  {
    key: "filter" as DeviceKey,
    label: "Filtr",
    icon: Filter,
    color: "#60a5fa",
    pin: "GPIO4",
    note: "HIGH = ON (klasyczna logika)",
  },
  {
    key: "aeration" as DeviceKey,
    label: "Napowietrzanie",
    icon: Wind,
    color: "#34d399",
    pin: "GPIO6 (serwo)",
    note: "Serwo PWM – attach na czas ruchu",
  },
];

function TimeField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label style={{ fontSize: 11, color: "#64748b" }}>{label}</label>
      <input
        type="time"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="rounded-xl px-3 py-2.5 outline-none"
        style={{
          background: "rgba(255,255,255,0.05)",
          border: "1px solid rgba(255,255,255,0.1)",
          color: "#e2e8f0",
          fontSize: 14,
          colorScheme: "dark",
          width: "100%",
        }}
      />
    </div>
  );
}

function durationLabel(start: string, end: string) {
  const [sh, sm] = start.split(":").map(Number);
  const [eh, em] = end.split(":").map(Number);
  const mins = eh * 60 + em - (sh * 60 + sm);
  if (mins <= 0) return "—";
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return h > 0 ? `${h}h ${m}min` : `${m}min`;
}

export function Schedule() {
  const { state, saveSchedule } = useDevice();
  const [localSchedule, setLocalSchedule] = useState(state.schedule);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    saveSchedule(localSchedule);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const updateDevice = (
    key: DeviceKey,
    field: "start" | "end" | "enabled",
    value: string | boolean
  ) => {
    setLocalSchedule((prev) => ({
      ...prev,
      [key]: { ...prev[key], [field]: value },
    }));
  };

  return (
    <div style={{ minHeight: "100%", color: "#e2e8f0" }}>
      {/* Header */}
      <div className="px-4 pt-4 pb-3 flex items-center justify-between">
        <div>
          <h1 style={{ fontSize: 18, color: "#f1f5f9" }}>Harmonogram</h1>
          <p style={{ fontSize: 11, color: "#64748b", marginTop: 1 }}>
            Okna czasowe urządzeń
          </p>
        </div>
        <button
          onClick={handleSave}
          className="flex items-center gap-2 rounded-xl px-4 py-2.5 transition-all active:scale-95"
          style={{
            background: saved
              ? "linear-gradient(135deg, #059669, #047857)"
              : "linear-gradient(135deg, #0891b2, #0e7490)",
            boxShadow: saved ? "0 0 16px rgba(5,150,105,0.4)" : "0 0 12px rgba(8,145,178,0.3)",
            color: "#fff",
            border: "none",
          }}
        >
          {saved ? <Check size={15} /> : <Save size={15} />}
          <span style={{ fontSize: 13 }}>{saved ? "Zapisano!" : "Zapisz"}</span>
        </button>
      </div>

      <div className="px-4 pb-4 flex flex-col gap-4">
        {/* Device cards — stacked */}
        {deviceConfigs.map(({ key, label, icon: Icon, color, pin, note }) => {
          const sched = localSchedule[key];
          return (
            <div
              key={key}
              className="rounded-2xl p-4 flex flex-col gap-3"
              style={{
                background: sched.enabled
                  ? `linear-gradient(135deg, ${color}10 0%, rgba(7,9,26,0.8) 100%)`
                  : "rgba(255,255,255,0.025)",
                border: `1px solid ${sched.enabled ? color + "30" : "rgba(255,255,255,0.07)"}`,
                transition: "all 0.2s",
              }}
            >
              {/* Card header */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div
                    className="rounded-xl p-2"
                    style={{ background: sched.enabled ? `${color}20` : "rgba(255,255,255,0.06)" }}
                  >
                    <Icon size={16} style={{ color: sched.enabled ? color : "#4b5563" }} />
                  </div>
                  <div>
                    <p style={{ fontSize: 14, color: sched.enabled ? "#e2e8f0" : "#9ca3af" }}>
                      {label}
                    </p>
                    <p style={{ fontSize: 10, color: "#475569" }}>{pin}</p>
                  </div>
                </div>
                <button
                  onClick={() => updateDevice(key, "enabled", !sched.enabled)}
                  className="transition-all active:scale-95"
                >
                  {sched.enabled ? (
                    <ToggleRight size={26} style={{ color }} />
                  ) : (
                    <ToggleLeft size={26} style={{ color: "#4b5563" }} />
                  )}
                </button>
              </div>

              {/* Time controls */}
              {sched.enabled ? (
                <>
                  <div
                    className="rounded-xl p-3 flex items-center justify-center gap-3"
                    style={{
                      background: "rgba(255,255,255,0.04)",
                      border: "1px solid rgba(255,255,255,0.06)",
                    }}
                  >
                    <span style={{ fontSize: 22, color, letterSpacing: "-0.02em", fontVariantNumeric: "tabular-nums" }}>
                      {sched.start}
                    </span>
                    <span style={{ fontSize: 14, color: "#475569" }}>→</span>
                    <span style={{ fontSize: 22, color, letterSpacing: "-0.02em", fontVariantNumeric: "tabular-nums" }}>
                      {sched.end}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <TimeField
                      label="Start"
                      value={sched.start}
                      onChange={(v) => updateDevice(key, "start", v)}
                    />
                    <TimeField
                      label="Koniec"
                      value={sched.end}
                      onChange={(v) => updateDevice(key, "end", v)}
                    />
                  </div>
                  <div
                    className="rounded-xl px-3 py-2 flex items-center gap-2"
                    style={{ background: `${color}0a`, border: `1px solid ${color}18` }}
                  >
                    <Clock size={11} style={{ color }} />
                    <span style={{ fontSize: 11, color: "#64748b" }}>
                      Czas aktywności:{" "}
                      <span style={{ color: "#94a3b8" }}>{durationLabel(sched.start, sched.end)}</span>
                    </span>
                  </div>
                </>
              ) : (
                <div
                  className="rounded-xl p-3 flex items-center justify-center"
                  style={{
                    background: "rgba(255,255,255,0.02)",
                    border: "1px dashed rgba(255,255,255,0.08)",
                    minHeight: 60,
                  }}
                >
                  <span style={{ fontSize: 12, color: "#475569" }}>Włącz, aby ustawić harmonogram</span>
                </div>
              )}

              <div
                className="rounded-lg px-2.5 py-1.5 flex items-start gap-1.5"
                style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}
              >
                <Info size={10} style={{ color: "#475569", marginTop: 1, flexShrink: 0 }} />
                <span style={{ fontSize: 10, color: "#475569" }}>{note}</span>
              </div>
            </div>
          );
        })}

        {/* Feeding card */}
        <div
          className="rounded-2xl p-4"
          style={{
            background: "linear-gradient(135deg, rgba(244,114,182,0.08) 0%, rgba(7,9,26,0.9) 100%)",
            border: "1px solid rgba(244,114,182,0.2)",
          }}
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="rounded-xl p-2" style={{ background: "rgba(244,114,182,0.2)" }}>
              <Fish size={16} style={{ color: "#f472b6" }} />
            </div>
            <div>
              <h2 style={{ fontSize: 14, color: "#e2e8f0" }}>Karmienie automatyczne</h2>
              <p style={{ fontSize: 10, color: "#64748b" }}>GPIO5 · czujnik GPIO12 · timeout 15s</p>
            </div>
          </div>

          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-2">
              <label style={{ fontSize: 12, color: "#94a3b8" }}>Tryb karmienia</label>
              <div className="flex gap-2">
                {[
                  { mode: 0, label: "Wyłączone" },
                  { mode: 1, label: "Codziennie" },
                ].map(({ mode, label }) => (
                  <button
                    key={mode}
                    onClick={() =>
                      setLocalSchedule((prev) => ({
                        ...prev,
                        feeding: { ...prev.feeding, mode },
                      }))
                    }
                    className="flex-1 py-2.5 rounded-xl transition-all active:scale-95"
                    style={{
                      background:
                        localSchedule.feeding.mode === mode
                          ? "rgba(244,114,182,0.18)"
                          : "rgba(255,255,255,0.04)",
                      border: `1px solid ${
                        localSchedule.feeding.mode === mode
                          ? "rgba(244,114,182,0.4)"
                          : "rgba(255,255,255,0.07)"
                      }`,
                      color: localSchedule.feeding.mode === mode ? "#f472b6" : "#6b7280",
                      fontSize: 13,
                      cursor: "pointer",
                    }}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>

            <TimeField
              label="Godzina karmienia"
              value={localSchedule.feeding.time}
              onChange={(v) =>
                setLocalSchedule((prev) => ({
                  ...prev,
                  feeding: { ...prev.feeding, time: v },
                }))
              }
            />

            <div
              className="rounded-xl p-3 flex items-center gap-3"
              style={{ background: "rgba(244,114,182,0.06)", border: "1px solid rgba(244,114,182,0.15)" }}
            >
              <div>
                <p style={{ fontSize: 11, color: "#f472b6" }}>Status</p>
                <p style={{ fontSize: 13, color: "#e2e8f0", marginTop: 1 }}>
                  {localSchedule.feeding.mode === 0
                    ? "Karmienie wyłączone"
                    : `Codziennie o ${localSchedule.feeding.time}`}
                </p>
                <p style={{ fontSize: 11, color: "#64748b", marginTop: 1 }}>
                  Ostatnie: {state.lastFeedTime}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Timeline */}
        <div
          className="rounded-2xl p-4"
          style={{
            background: "rgba(255,255,255,0.025)",
            border: "1px solid rgba(255,255,255,0.07)",
          }}
        >
          <h2 style={{ fontSize: 13, color: "#94a3b8", marginBottom: 16 }}>Oś czasu harmonogramu</h2>
          <div className="relative" style={{ height: 72 }}>
            <div
              className="absolute inset-x-0 rounded-full"
              style={{ top: 22, height: 3, background: "rgba(255,255,255,0.06)" }}
            />
            {[0, 6, 12, 18, 24].map((h) => (
              <div
                key={h}
                className="absolute flex flex-col items-center"
                style={{ left: `${(h / 24) * 100}%`, top: 16, transform: "translateX(-50%)" }}
              >
                <div style={{ width: 1, height: 12, background: "rgba(255,255,255,0.1)" }} />
                <span style={{ fontSize: 8, color: "#475569", marginTop: 3 }}>
                  {String(h).padStart(2, "0")}:00
                </span>
              </div>
            ))}
            {[
              { key: "light" as DeviceKey, color: "#fbbf24", offset: -14 },
              { key: "filter" as DeviceKey, color: "#60a5fa", offset: -7 },
              { key: "aeration" as DeviceKey, color: "#34d399", offset: 0 },
            ].map(({ key, color, offset }) => {
              const s = localSchedule[key];
              if (!s.enabled) return null;
              const [sh, sm] = s.start.split(":").map(Number);
              const [eh, em] = s.end.split(":").map(Number);
              const startPct = ((sh * 60 + sm) / (24 * 60)) * 100;
              const endPct = ((eh * 60 + em) / (24 * 60)) * 100;
              return (
                <div
                  key={key}
                  className="absolute rounded-full"
                  style={{
                    left: `${startPct}%`,
                    width: `${endPct - startPct}%`,
                    top: 22 + offset,
                    height: 5,
                    background: color,
                    opacity: 0.7,
                    boxShadow: `0 0 5px ${color}`,
                  }}
                />
              );
            })}
            {localSchedule.feeding.mode !== 0 && (() => {
              const [fh, fm] = localSchedule.feeding.time.split(":").map(Number);
              const pct = ((fh * 60 + fm) / (24 * 60)) * 100;
              return (
                <div
                  className="absolute"
                  style={{ left: `${pct}%`, top: 14, transform: "translateX(-50%)" }}
                >
                  <div
                    style={{
                      width: 8,
                      height: 8,
                      borderRadius: "50%",
                      background: "#f472b6",
                      boxShadow: "0 0 6px #f472b6",
                    }}
                  />
                </div>
              );
            })()}
          </div>
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 mt-1">
            {[
              { color: "#fbbf24", label: "Światło" },
              { color: "#60a5fa", label: "Filtr" },
              { color: "#34d399", label: "Napowietrzanie" },
              { color: "#f472b6", label: "Karmienie" },
            ].map(({ color, label }) => (
              <div key={label} className="flex items-center gap-1.5">
                <div style={{ width: 12, height: 3, background: color, borderRadius: 2, opacity: 0.7 }} />
                <span style={{ fontSize: 10, color: "#64748b" }}>{label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
