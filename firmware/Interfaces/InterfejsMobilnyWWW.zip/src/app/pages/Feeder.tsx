import { useState } from "react";
import {
  Fish,
  Clock,
  CheckCircle2,
  AlertCircle,
  Activity,
  Cpu,
  Timer,
  BarChart3,
} from "lucide-react";
import { useDevice } from "../deviceContext";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const feedingHistory = [
  { day: "Pon", count: 1 },
  { day: "Wt", count: 1 },
  { day: "Śr", count: 1 },
  { day: "Czw", count: 2 },
  { day: "Pt", count: 1 },
  { day: "Sob", count: 1 },
  { day: "Nd", count: 1 },
];

export function Feeder() {
  const { state, feedNow } = useDevice();
  const [feeding, setFeeding] = useState<"idle" | "running" | "done">("idle");
  const [progress, setProgress] = useState(0);

  const handleFeed = () => {
    if (feeding !== "idle") return;
    setFeeding("running");
    setProgress(0);
    feedNow();
    let p = 0;
    const interval = setInterval(() => {
      p += 7;
      setProgress(Math.min(p, 100));
      if (p >= 100) {
        clearInterval(interval);
        setFeeding("done");
        setTimeout(() => { setFeeding("idle"); setProgress(0); }, 3000);
      }
    }, 100);
  };

  return (
    <div style={{ minHeight: "100%", color: "#e2e8f0" }}>
      {/* Header */}
      <div className="px-4 pt-4 pb-3">
        <h1 style={{ fontSize: 18, color: "#f1f5f9" }}>Karmnik</h1>
        <p style={{ fontSize: 11, color: "#64748b", marginTop: 1 }}>
          Sterowanie ręczne i konfiguracja
        </p>
      </div>

      <div className="px-4 pb-4 flex flex-col gap-4">
        {/* Manual feed — centered hero button */}
        <div
          className="rounded-2xl p-5 flex flex-col items-center gap-4"
          style={{
            background: "linear-gradient(135deg, rgba(244,114,182,0.1) 0%, rgba(7,9,26,0.9) 100%)",
            border: "1px solid rgba(244,114,182,0.2)",
          }}
        >
          <p style={{ fontSize: 13, color: "#94a3b8" }}>Karmienie ręczne</p>

          <div className="relative" style={{ width: 150, height: 150 }}>
            <svg
              className="absolute inset-0"
              style={{ width: 150, height: 150, transform: "rotate(-90deg)" }}
              viewBox="0 0 150 150"
            >
              <circle cx="75" cy="75" r="68" fill="none" stroke="rgba(244,114,182,0.1)" strokeWidth="6" />
              {feeding === "running" && (
                <circle
                  cx="75"
                  cy="75"
                  r="68"
                  fill="none"
                  stroke="#f472b6"
                  strokeWidth="6"
                  strokeLinecap="round"
                  strokeDasharray={`${2 * Math.PI * 68}`}
                  strokeDashoffset={`${2 * Math.PI * 68 * (1 - progress / 100)}`}
                  style={{ transition: "stroke-dashoffset 0.1s linear" }}
                />
              )}
              {feeding === "done" && (
                <circle cx="75" cy="75" r="68" fill="none" stroke="#4ade80" strokeWidth="6" />
              )}
            </svg>

            <button
              onClick={handleFeed}
              disabled={feeding !== "idle"}
              className="absolute inset-3 flex flex-col items-center justify-center rounded-full transition-all active:scale-95"
              style={{
                background:
                  feeding === "done"
                    ? "rgba(74,222,128,0.12)"
                    : "rgba(244,114,182,0.1)",
                border: `2px solid ${feeding === "done" ? "#4ade80" : feeding === "running" ? "#f472b6" : "rgba(244,114,182,0.4)"}`,
                boxShadow:
                  feeding === "done"
                    ? "0 0 28px rgba(74,222,128,0.25)"
                    : "0 0 18px rgba(244,114,182,0.15)",
                cursor: feeding !== "idle" ? "default" : "pointer",
              }}
            >
              {feeding === "done" ? (
                <>
                  <CheckCircle2 size={30} style={{ color: "#4ade80" }} />
                  <span style={{ fontSize: 11, color: "#4ade80", marginTop: 6 }}>Gotowe!</span>
                </>
              ) : feeding === "running" ? (
                <>
                  <Activity size={30} style={{ color: "#f472b6" }} />
                  <span style={{ fontSize: 11, color: "#f472b6", marginTop: 6 }}>
                    {Math.round(progress)}%
                  </span>
                </>
              ) : (
                <>
                  <Fish size={30} style={{ color: "#f472b6" }} />
                  <span style={{ fontSize: 11, color: "#f472b6", marginTop: 6 }}>Karm teraz</span>
                </>
              )}
            </button>
          </div>

          <p style={{ fontSize: 12, color: "#64748b", textAlign: "center" }}>
            {feeding === "running"
              ? "Karmnik w trakcie pracy… timeout: 15s"
              : feeding === "done"
              ? "Karmienie zakończone pomyślnie"
              : "Naciśnij, aby uruchomić karmnik jednorazowo"}
          </p>
        </div>

        {/* Last feed / schedule info */}
        <div
          className="rounded-2xl p-4 grid grid-cols-2 gap-3"
          style={{
            background: "rgba(255,255,255,0.025)",
            border: "1px solid rgba(255,255,255,0.07)",
          }}
        >
          <div className="flex items-start gap-2.5">
            <div className="rounded-xl p-1.5 shrink-0" style={{ background: "rgba(244,114,182,0.12)" }}>
              <Clock size={14} style={{ color: "#f472b6" }} />
            </div>
            <div>
              <p style={{ fontSize: 10, color: "#64748b" }}>Ostatnie karmienie</p>
              <p style={{ fontSize: 13, color: "#e2e8f0" }}>{state.lastFeedTime}</p>
            </div>
          </div>
          <div className="flex items-start gap-2.5">
            <div className="rounded-xl p-1.5 shrink-0" style={{ background: "rgba(244,114,182,0.12)" }}>
              <Timer size={14} style={{ color: "#f472b6" }} />
            </div>
            <div>
              <p style={{ fontSize: 10, color: "#64748b" }}>Harmonogram</p>
              <p style={{ fontSize: 13, color: "#e2e8f0" }}>
                {state.schedule.feeding.mode === 0
                  ? "Wyłączony"
                  : `${state.schedule.feeding.time}`}
              </p>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: "Dziś", value: "1", color: "#f472b6" },
            { label: "Timeout", value: "15s", color: "#fbbf24" },
            { label: "Tryb", value: state.schedule.feeding.mode === 0 ? "Wył." : "Dzienny", color: "#34d399" },
          ].map(({ label, value, color }) => (
            <div
              key={label}
              className="rounded-2xl p-3"
              style={{ background: `${color}0a`, border: `1px solid ${color}20` }}
            >
              <p style={{ fontSize: 22, color, letterSpacing: "-0.02em" }}>{value}</p>
              <p style={{ fontSize: 10, color: "#64748b", marginTop: 2 }}>{label}</p>
            </div>
          ))}
        </div>

        {/* Weekly chart */}
        <div
          className="rounded-2xl p-4"
          style={{
            background: "rgba(255,255,255,0.025)",
            border: "1px solid rgba(255,255,255,0.07)",
          }}
        >
          <div className="flex items-center gap-2 mb-3">
            <BarChart3 size={14} style={{ color: "#f472b6" }} />
            <h2 style={{ fontSize: 13, color: "#94a3b8" }}>Aktywność — ostatni tydzień</h2>
          </div>
          <ResponsiveContainer width="100%" height={100}>
            <BarChart data={feedingHistory} margin={{ top: 0, right: 0, left: -25, bottom: 0 }}>
              <XAxis
                key="xaxis"
                dataKey="day"
                tick={{ fill: "#475569", fontSize: 10 }}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                key="yaxis"
                tick={{ fill: "#475569", fontSize: 10 }}
                tickLine={false}
                axisLine={false}
                allowDecimals={false}
              />
              <Tooltip
                key="tooltip"
                contentStyle={{
                  background: "#0f1829",
                  border: "1px solid rgba(244,114,182,0.3)",
                  borderRadius: 10,
                  color: "#e2e8f0",
                  fontSize: 12,
                }}
                cursor={{ fill: "rgba(255,255,255,0.04)" }}
              />
              <Bar key="bar-count" dataKey="count" fill="#f472b6" radius={[4, 4, 0, 0]} opacity={0.8} name="Karmień" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Hardware info */}
        <div
          className="rounded-2xl p-4"
          style={{
            background: "rgba(255,255,255,0.025)",
            border: "1px solid rgba(255,255,255,0.07)",
          }}
        >
          <div className="flex items-center gap-2 mb-3">
            <Cpu size={14} style={{ color: "#94a3b8" }} />
            <h2 style={{ fontSize: 13, color: "#94a3b8" }}>Parametry sprzętowe</h2>
          </div>
          <div className="flex flex-col gap-2">
            {[
              { label: "Silnik karmnika", value: "GPIO5 (FEEDER_PIN)", color: "#f472b6" },
              { label: "Czujnik ukończenia", value: "GPIO12 (FEEDER_SENSOR_PIN)", color: "#f472b6" },
              { label: "Timeout bezpieczeństwa", value: "15 sekund", color: "#fbbf24" },
              { label: "Karmienie API", value: "POST /api/action · feed_now", color: "#22d3ee" },
              { label: "Ostatnie zdarzenie", value: state.lastFeedTime, color: "#94a3b8" },
            ].map(({ label, value, color }) => (
              <div
                key={label}
                className="flex items-center justify-between rounded-xl px-3 py-2.5"
                style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}
              >
                <p style={{ fontSize: 11, color: "#64748b" }}>{label}</p>
                <p style={{ fontSize: 11, color, textAlign: "right", maxWidth: "55%" }}>{value}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Warning */}
        <div
          className="rounded-2xl px-4 py-3.5 flex items-start gap-3"
          style={{
            background: "rgba(251,191,36,0.06)",
            border: "1px solid rgba(251,191,36,0.15)",
          }}
        >
          <AlertCircle size={14} style={{ color: "#fbbf24", flexShrink: 0, marginTop: 1 }} />
          <p style={{ fontSize: 12, color: "#94a3b8" }}>
            Karmnik posiada timeout bezpieczeństwa (15s) oraz czujnik potwierdzenia zakończenia cyklu.
            Nieudane próby są logowane jako WARN.
          </p>
        </div>
      </div>
    </div>
  );
}
