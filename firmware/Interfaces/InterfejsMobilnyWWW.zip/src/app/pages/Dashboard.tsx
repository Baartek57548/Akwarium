import { useState, useEffect } from "react";
import {
  Thermometer,
  Lightbulb,
  Filter,
  Flame,
  Wind,
  Fish,
  Wifi,
  BatteryFull,
  BatteryMedium,
  BatteryLow,
  Clock,
  Activity,
  Zap,
  TrendingDown,
  Minus,
  ChevronRight,
  RefreshCw,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
} from "recharts";
import { useDevice } from "../deviceContext";
import { tempHistory } from "../tempHistory";
import { Link } from "react-router";

function StatCard({
  label,
  value,
  unit,
  sublabel,
  icon: Icon,
  color,
  trend,
}: {
  label: string;
  value: string | number;
  unit?: string;
  sublabel?: string;
  icon: React.ElementType;
  color: string;
  trend?: "up" | "down" | "stable";
}) {
  const TrendIcon = trend === "down" ? TrendingDown : Minus;
  return (
    <div
      className="rounded-2xl p-4 flex flex-col gap-2"
      style={{
        background: `linear-gradient(135deg, ${color}12 0%, rgba(7,9,26,0.8) 100%)`,
        border: `1px solid ${color}28`,
      }}
    >
      <div className="flex items-center justify-between">
        <div
          className="rounded-xl p-1.5"
          style={{ background: `${color}18`, border: `1px solid ${color}25` }}
        >
          <Icon size={15} style={{ color }} />
        </div>
        {trend && (
          <TrendIcon
            size={12}
            style={{
              color: trend === "down" ? "#60a5fa" : "#94a3b8",
            }}
          />
        )}
      </div>
      <div>
        <div className="flex items-end gap-1">
          <span style={{ fontSize: 24, color: "#f1f5f9", letterSpacing: "-0.03em", lineHeight: 1 }}>
            {value}
          </span>
          {unit && <span style={{ fontSize: 12, color: "#64748b", paddingBottom: 1 }}>{unit}</span>}
        </div>
        <p style={{ fontSize: 11, color: "#64748b", marginTop: 2 }}>{label}</p>
        {sublabel && <p style={{ fontSize: 10, color, marginTop: 1 }}>{sublabel}</p>}
      </div>
    </div>
  );
}

function RelayCard({
  label,
  sublabel,
  icon: Icon,
  active,
  color,
  onToggle,
}: {
  label: string;
  sublabel?: string;
  icon: React.ElementType;
  active: boolean;
  color: string;
  onToggle: () => void;
}) {
  return (
    <button
      onClick={onToggle}
      className="rounded-2xl p-3.5 flex items-center gap-3 text-left w-full transition-all active:scale-[0.97]"
      style={{
        background: active
          ? `linear-gradient(135deg, ${color}15 0%, ${color}06 100%)`
          : "rgba(255,255,255,0.03)",
        border: `1px solid ${active ? color + "40" : "rgba(255,255,255,0.07)"}`,
        boxShadow: active ? `0 4px 16px ${color}15` : "none",
        cursor: "pointer",
      }}
    >
      <div
        className="rounded-xl p-2 shrink-0"
        style={{ background: active ? `${color}20` : "rgba(255,255,255,0.06)" }}
      >
        <Icon size={16} style={{ color: active ? color : "#4b5563" }} />
      </div>
      <div className="flex-1 min-w-0">
        <p style={{ fontSize: 13, color: active ? "#e2e8f0" : "#9ca3af" }}>{label}</p>
        {sublabel && (
          <p style={{ fontSize: 10, color: active ? color : "#4b5563", marginTop: 1 }} className="truncate">
            {sublabel}
          </p>
        )}
      </div>
      <div
        className="rounded-full shrink-0"
        style={{
          width: 8,
          height: 8,
          background: active ? color : "#374151",
          boxShadow: active ? `0 0 7px ${color}` : "none",
        }}
      />
    </button>
  );
}

const ChartTooltip = ({ active, payload, label }: any) => {
  if (active && payload?.length) {
    return (
      <div
        className="rounded-xl px-3 py-2"
        style={{
          background: "#0f1829",
          border: "1px solid rgba(6,182,212,0.3)",
          color: "#e2e8f0",
          fontSize: 12,
        }}
      >
        <p style={{ color: "#64748b", marginBottom: 2 }}>{label}</p>
        <p style={{ color: "#22d3ee" }}>{payload[0].value.toFixed(2)} °C</p>
      </div>
    );
  }
  return null;
};

export function Dashboard() {
  const { state, toggleLight, toggleFilter, toggleHeater, setAeration, feedNow } = useDevice();
  const [time, setTime] = useState(new Date());
  const [feedFeedback, setFeedFeedback] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const handleFeed = () => {
    feedNow();
    setFeedFeedback(true);
    setTimeout(() => setFeedFeedback(false), 3000);
  };

  const handleRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1000);
  };

  const chartData = tempHistory;
  const minTemp = Math.min(...chartData.map((d) => d.temp)) - 0.3;
  const maxTemp = Math.max(...chartData.map((d) => d.temp)) + 0.3;

  const batColor =
    state.batteryPercent > 70 ? "#4ade80" : state.batteryPercent > 35 ? "#fbbf24" : "#f87171";
  const BatIcon =
    state.batteryPercent > 70 ? BatteryFull : state.batteryPercent > 35 ? BatteryMedium : BatteryLow;
  const tempColor =
    state.currentTemp > 27 ? "#f87171" : state.currentTemp < 23 ? "#60a5fa" : "#22d3ee";

  return (
    <div className="flex flex-col" style={{ minHeight: "100%" }}>
      {/* Page header */}
      <div className="px-4 pt-4 pb-3 flex items-center justify-between">
        <div>
          <h1 style={{ fontSize: 18, color: "#f1f5f9" }}>Panel główny</h1>
          <p style={{ fontSize: 11, color: "#64748b", marginTop: 1 }}>
            {time.toLocaleDateString("pl-PL", { weekday: "short", day: "numeric", month: "short" })}
            {" · "}
            {time.toLocaleTimeString("pl-PL")}
          </p>
        </div>
        <button
          onClick={handleRefresh}
          className="flex items-center gap-1.5 rounded-xl px-3 py-2 transition-all active:scale-95"
          style={{
            border: "1px solid rgba(255,255,255,0.08)",
            background: "rgba(255,255,255,0.04)",
            color: "#94a3b8",
          }}
        >
          <RefreshCw size={13} className={refreshing ? "animate-spin" : ""} />
          <span style={{ fontSize: 11 }}>Odśwież</span>
        </button>
      </div>

      <div className="flex flex-col gap-4 px-4 pb-4">
        {/* Stat cards — 2x2 grid */}
        <div className="grid grid-cols-2 gap-3">
          <StatCard
            label="Temperatura wody"
            value={state.currentTemp.toFixed(1)}
            unit="°C"
            sublabel={`cel: ${state.targetTemp}°C ±${state.hysteresis}°C`}
            icon={Thermometer}
            color={tempColor}
            trend="stable"
          />
          <StatCard
            label="Bateria RTC"
            value={state.batteryPercent}
            unit="%"
            sublabel={`${state.batteryVoltage.toFixed(2)} V`}
            icon={BatIcon}
            color={batColor}
            trend={state.batteryPercent < 35 ? "down" : "stable"}
          />
          <StatCard
            label="Sygnał WiFi"
            value={state.wifi.rssi}
            unit="dBm"
            sublabel={state.wifi.connected ? state.wifi.ssid : "Offline"}
            icon={Wifi}
            color={state.wifi.rssi > -60 ? "#4ade80" : state.wifi.rssi > -75 ? "#fbbf24" : "#f87171"}
            trend="stable"
          />
          <StatCard
            label="Czas pracy"
            value={state.uptime}
            icon={Zap}
            color="#a78bfa"
            sublabel="ESP32-S3"
          />
        </div>

        {/* Relays */}
        <div
          className="rounded-2xl p-4"
          style={{
            background: "rgba(255,255,255,0.025)",
            border: "1px solid rgba(255,255,255,0.07)",
          }}
        >
          <div className="flex items-center justify-between mb-3">
            <h2 style={{ fontSize: 13, color: "#94a3b8" }}>Przekaźniki</h2>
            <span style={{ fontSize: 11, color: "#475569" }}>
              {[state.lightOn, state.filterOn, state.heaterOn, state.aerationAngle > 0].filter(Boolean).length} / 4 aktywnych
            </span>
          </div>
          <div className="flex flex-col gap-2">
            <RelayCard
              label="Światło"
              sublabel={state.lightOn ? "GPIO17 · AKTYWNY" : "GPIO17 · wyłączone"}
              icon={Lightbulb}
              active={state.lightOn}
              color="#fbbf24"
              onToggle={toggleLight}
            />
            <RelayCard
              label="Filtr"
              sublabel={state.filterOn ? "GPIO4 · AKTYWNY" : "GPIO4 · wyłączony"}
              icon={Filter}
              active={state.filterOn}
              color="#60a5fa"
              onToggle={toggleFilter}
            />
            <RelayCard
              label="Grzałka"
              sublabel={state.heaterOn ? "GPIO3 · AKTYWNA" : "GPIO3 · wyłączona"}
              icon={Flame}
              active={state.heaterOn}
              color="#fb923c"
              onToggle={toggleHeater}
            />
            <RelayCard
              label="Napowietrzanie"
              sublabel={
                state.aerationAngle > 0
                  ? `GPIO6 · serwo ${state.aerationAngle}°`
                  : "GPIO6 · wyłączone"
              }
              icon={Wind}
              active={state.aerationAngle > 0}
              color="#34d399"
              onToggle={() => setAeration(state.aerationAngle > 0 ? 0 : 45)}
            />
          </div>
        </div>

        {/* Quick feed */}
        <div
          className="rounded-2xl p-4 flex items-center gap-4"
          style={{
            background: "rgba(255,255,255,0.025)",
            border: "1px solid rgba(255,255,255,0.07)",
          }}
        >
          <button
            onClick={handleFeed}
            className="relative flex flex-col items-center justify-center rounded-full transition-all active:scale-95 shrink-0"
            style={{
              width: 80,
              height: 80,
              background: feedFeedback
                ? "linear-gradient(135deg, rgba(52,211,153,0.2), rgba(52,211,153,0.05))"
                : "linear-gradient(135deg, rgba(244,114,182,0.2), rgba(244,114,182,0.05))",
              border: `2px solid ${feedFeedback ? "#34d399" : "#f472b6"}`,
              boxShadow: feedFeedback
                ? "0 0 24px rgba(52,211,153,0.3)"
                : "0 0 18px rgba(244,114,182,0.2)",
              cursor: "pointer",
            }}
          >
            <Fish size={26} style={{ color: feedFeedback ? "#34d399" : "#f472b6" }} />
            <span style={{ fontSize: 9, color: feedFeedback ? "#34d399" : "#f472b6", marginTop: 4 }}>
              {feedFeedback ? "Karmię..." : "Karm"}
            </span>
          </button>
          <div className="flex-1">
            <h2 style={{ fontSize: 13, color: "#e2e8f0" }}>Karmnik</h2>
            <p style={{ fontSize: 11, color: "#64748b", marginTop: 2 }}>
              Tryb: {state.schedule.feeding.mode === 0 ? "Wyłączony" : `Codziennie ${state.schedule.feeding.time}`}
            </p>
            <p style={{ fontSize: 11, color: "#475569", marginTop: 2 }}>
              Ostatnie: {state.lastFeedTime}
            </p>
            <Link
              to="/feeder"
              className="inline-flex items-center gap-1 mt-2"
              style={{ fontSize: 11, color: "#22d3ee" }}
            >
              Zarządzaj <ChevronRight size={11} />
            </Link>
          </div>
        </div>

        {/* Schedule overview */}
        <div
          className="rounded-2xl p-4"
          style={{
            background: "rgba(255,255,255,0.025)",
            border: "1px solid rgba(255,255,255,0.07)",
          }}
        >
          <div className="flex items-center justify-between mb-3">
            <h2 style={{ fontSize: 13, color: "#94a3b8" }}>Harmonogram dziś</h2>
            <Link to="/schedule">
              <span
                className="flex items-center gap-1"
                style={{ fontSize: 11, color: "#22d3ee" }}
              >
                Edytuj <ChevronRight size={11} />
              </span>
            </Link>
          </div>
          <div className="flex flex-col gap-2">
            {[
              {
                label: "Światło",
                icon: Lightbulb,
                color: "#fbbf24",
                value: state.schedule.light.enabled
                  ? `${state.schedule.light.start} – ${state.schedule.light.end}`
                  : "Wyłączone",
                active: state.schedule.light.enabled,
              },
              {
                label: "Filtr",
                icon: Filter,
                color: "#60a5fa",
                value: state.schedule.filter.enabled
                  ? `${state.schedule.filter.start} – ${state.schedule.filter.end}`
                  : "Wyłączony",
                active: state.schedule.filter.enabled,
              },
              {
                label: "Napowietrzanie",
                icon: Wind,
                color: "#34d399",
                value: state.schedule.aeration.enabled
                  ? `${state.schedule.aeration.start} – ${state.schedule.aeration.end}`
                  : "Wyłączone",
                active: state.schedule.aeration.enabled,
              },
              {
                label: "Karmienie",
                icon: Fish,
                color: "#f472b6",
                value:
                  state.schedule.feeding.mode === 0
                    ? "Wyłączone"
                    : `Codziennie ${state.schedule.feeding.time}`,
                active: state.schedule.feeding.mode !== 0,
              },
            ].map(({ label, icon: Icon, color, value, active }) => (
              <div
                key={label}
                className="flex items-center gap-3 rounded-xl px-3 py-2.5"
                style={{
                  background: active ? `${color}0a` : "rgba(255,255,255,0.02)",
                  border: `1px solid ${active ? color + "20" : "rgba(255,255,255,0.05)"}`,
                }}
              >
                <div className="rounded-lg p-1.5" style={{ background: `${color}15`, flexShrink: 0 }}>
                  <Icon size={12} style={{ color: active ? color : "#4b5563" }} />
                </div>
                <span style={{ fontSize: 12, color: "#cbd5e1", flex: 1 }}>{label}</span>
                <span style={{ fontSize: 11, color: active ? "#94a3b8" : "#374151" }}>{value}</span>
              </div>
            ))}
          </div>
          <div
            className="mt-2 rounded-xl px-3 py-2 flex items-center gap-2"
            style={{ background: "rgba(34,211,238,0.06)", border: "1px solid rgba(34,211,238,0.12)" }}
          >
            <Clock size={11} style={{ color: "#22d3ee" }} />
            <span style={{ fontSize: 11, color: "#64748b" }}>
              Ostatnie karmienie: <span style={{ color: "#94a3b8" }}>{state.lastFeedTime}</span>
            </span>
          </div>
        </div>

        {/* Temperature chart */}
        <div
          className="rounded-2xl p-4"
          style={{
            background: "rgba(255,255,255,0.025)",
            border: "1px solid rgba(255,255,255,0.07)",
          }}
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Activity size={14} style={{ color: "#22d3ee" }} />
              <div>
                <h2 style={{ fontSize: 13, color: "#94a3b8" }}>Historia temperatury</h2>
                <p style={{ fontSize: 10, color: "#475569" }}>Ostatnie 24h · co 30 min</p>
              </div>
            </div>
            <div className="flex flex-col items-end gap-0.5">
              <span style={{ fontSize: 12, color: "#22d3ee" }}>{state.currentTemp.toFixed(1)}°C</span>
              <span style={{ fontSize: 10, color: "#475569" }}>aktualna</span>
            </div>
          </div>
          <div className="flex gap-4 mb-3">
            {[
              { label: "Min", val: `${Math.min(...chartData.map((d) => d.temp)).toFixed(1)}°`, color: "#60a5fa" },
              { label: "Max", val: `${Math.max(...chartData.map((d) => d.temp)).toFixed(1)}°`, color: "#f87171" },
              { label: "Cel", val: `${state.targetTemp.toFixed(1)}°`, color: "#a78bfa" },
            ].map(({ label, val, color }) => (
              <div key={label}>
                <p style={{ fontSize: 9, color: "#475569" }}>{label}</p>
                <p style={{ fontSize: 13, color }}>{val}</p>
              </div>
            ))}
          </div>
          <ResponsiveContainer width="100%" height={140}>
            <AreaChart data={chartData} margin={{ top: 5, right: 5, bottom: 0, left: -15 }}>
              <defs key="defs">
                <linearGradient id="tempGradMobile" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#22d3ee" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#22d3ee" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis
                key="xaxis"
                dataKey="time"
                tick={{ fill: "#475569", fontSize: 9 }}
                tickLine={false}
                axisLine={false}
                interval={7}
              />
              <YAxis
                key="yaxis"
                domain={[minTemp, maxTemp]}
                tick={{ fill: "#475569", fontSize: 9 }}
                tickLine={false}
                axisLine={false}
                tickFormatter={(v) => `${v.toFixed(0)}°`}
              />
              <Tooltip key="tooltip" content={<ChartTooltip />} />
              <ReferenceLine
                key="ref-target"
                y={state.targetTemp}
                stroke="#a78bfa"
                strokeWidth={1}
                strokeDasharray="4 4"
                opacity={0.5}
              />
              <ReferenceLine
                key="ref-emergency"
                y={28}
                stroke="#f87171"
                strokeWidth={1}
                strokeDasharray="4 2"
                opacity={0.4}
              />
              <Area
                key="area-temp"
                type="monotone"
                dataKey="temp"
                stroke="#22d3ee"
                strokeWidth={2}
                fill="url(#tempGradMobile)"
                dot={false}
                activeDot={{ r: 3, fill: "#22d3ee", stroke: "#0f172a", strokeWidth: 2 }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Recent logs */}
        <div
          className="rounded-2xl p-4"
          style={{
            background: "rgba(255,255,255,0.025)",
            border: "1px solid rgba(255,255,255,0.07)",
          }}
        >
          <div className="flex items-center justify-between mb-3">
            <h2 style={{ fontSize: 13, color: "#94a3b8" }}>Ostatnie logi</h2>
            <Link to="/logs">
              <span className="flex items-center gap-1" style={{ fontSize: 11, color: "#22d3ee" }}>
                Wszystkie <ChevronRight size={11} />
              </span>
            </Link>
          </div>
          <div className="flex flex-col gap-1.5">
            {state.logs.slice(0, 4).map((log) => {
              const levelColor =
                log.level === "INFO" ? "#22d3ee" : log.level === "WARN" ? "#fbbf24" : "#f87171";
              return (
                <div
                  key={log.id}
                  className="flex items-start gap-2 rounded-lg px-2.5 py-2"
                  style={{ background: "rgba(255,255,255,0.02)" }}
                >
                  <span
                    className="rounded px-1.5 py-0.5 shrink-0 mt-0.5"
                    style={{
                      fontSize: 8,
                      color: levelColor,
                      background: `${levelColor}15`,
                      border: `1px solid ${levelColor}25`,
                      letterSpacing: "0.04em",
                    }}
                  >
                    {log.level}
                  </span>
                  <div className="min-w-0">
                    <span style={{ fontSize: 10, color: "#64748b" }}>{log.timestamp} · </span>
                    <span style={{ fontSize: 11, color: "#cbd5e1" }}>{log.message}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
